package com.blackbox.offline;
import org.json.*;
public class Entry {
 public String id,path,created,transcript,summary,status; public long duration; public boolean important;
 Entry(String i,String p,String c,long d,String t,String s){id=i;path=p;created=c;duration=d;transcript=t;summary=s;status=t.isEmpty()?"В очереди":"Готово";}
 JSONObject json() throws JSONException {JSONObject o=new JSONObject();o.put("id",id);o.put("path",path);o.put("created",created);o.put("duration",duration);o.put("transcript",transcript);o.put("summary",summary);o.put("important",important);o.put("status",status);return o;}
 static Entry from(JSONObject o){Entry e=new Entry(o.optString("id"),o.optString("path"),o.optString("created"),o.optLong("duration"),o.optString("transcript"),o.optString("summary"));e.important=o.optBoolean("important",false);e.status=o.optString("status",e.transcript.isEmpty()?"В очереди":"Готово");return e;}
}
