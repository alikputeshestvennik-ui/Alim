package com.blackbox.offline;

import android.content.Context;
import java.io.File;

/**
 * Fully local Whisper + Qwen engine bridge.
 * Application has NO android.permission.INTERNET.
 */
public class LocalAiEngine {
    private final Context app;
    private final QwenEngine qwenEngine;
    private static volatile boolean whisperLoaded = false;
    private static volatile boolean attempted = false;

    public LocalAiEngine(Context c) {
        this.app = c.getApplicationContext();
        this.qwenEngine = new QwenEngine(app);
    }

    private static synchronized void ensureNative() {
        if (!attempted) {
            attempted = true;
            try {
                System.loadLibrary("blackbox_ai");
                whisperLoaded = true;
            } catch (Throwable t) {
                whisperLoaded = false;
            }
        }
    }

    public boolean whisperReady() {
        ensureNative();
        return whisperLoaded && ModelManager.installed(app, ModelManager.WHISPER);
    }

    public boolean qwenReady() {
        return qwenEngine.isModelPresent();
    }

    public boolean ready() {
        return whisperReady();
    }

    public String transcribe(String path) throws Exception {
        if (!ModelManager.installed(app, ModelManager.WHISPER)) {
            throw new IllegalStateException("Импортируйте ggml-base.bin в разделе AI-модели.");
        }
        ensureNative();
        if (!whisperLoaded) {
            throw new IllegalStateException("Нативная библиотека whisper не загружена.");
        }
        File model = ModelManager.file(app, ModelManager.WHISPER);
        return nativeTranscribePcm(PcmDecoder.decode16kMono(path), model.getAbsolutePath());
    }

    public String answer(String question, String context) {
        return qwenEngine.answerQuestion(question, context);
    }

    public String summarize(String context, String date) {
        return qwenEngine.summarizePeriod(context, date);
    }

    public String summarize(String context) {
        return summarize(context, null);
    }

    private native String nativeTranscribePcm(float[] pcm, String whisperModel);
}
