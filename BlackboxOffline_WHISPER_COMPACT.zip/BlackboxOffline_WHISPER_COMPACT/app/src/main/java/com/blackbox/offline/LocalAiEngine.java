package com.blackbox.offline;

import android.content.Context;
import java.io.File;

/** Fully local Whisper bridge; application has no INTERNET permission. */
public class LocalAiEngine {
    private final Context app;
    private static volatile boolean whisperLoaded = false;
    private static volatile boolean attempted = false;

    public LocalAiEngine(Context c) {
        app = c.getApplicationContext();
    }

    private static synchronized boolean nativeAvailable() {
        if (!attempted) {
            attempted = true;
            try {
                System.loadLibrary("blackbox_ai");
                whisperLoaded = true;
            } catch (Throwable t) {
                t.printStackTrace();
                whisperLoaded = false;
            }
        }
        return whisperLoaded;
    }

    public boolean whisperReady() {
        return ModelManager.installed(app, ModelManager.WHISPER) && nativeAvailable();
    }

    public boolean qwenReady() {
        return false;
    }

    public boolean ready() {
        return whisperReady();
    }

    public String transcribe(String path) throws Exception {
        if (!ModelManager.installed(app, ModelManager.WHISPER)) {
            throw new IllegalStateException("Импортируй модель Whisper в AI-модели.");
        }
        if (!nativeAvailable()) {
            throw new IllegalStateException("Нативный движок Whisper не загружен.");
        }
        File modelFile = ModelManager.file(app, ModelManager.WHISPER);
        return nativeTranscribePcm(PcmDecoder.decode16kMono(path), modelFile.getAbsolutePath());
    }

    public String answer(String question, String context) throws Exception {
        return "Локальная модель Qwen/LLM пока не подключена в этой версии.";
    }

    public String summarize(String context) throws Exception {
        return answer("Итоги", context);
    }

    private native String nativeTranscribePcm(float[] pcm, String whisperModel);
}
