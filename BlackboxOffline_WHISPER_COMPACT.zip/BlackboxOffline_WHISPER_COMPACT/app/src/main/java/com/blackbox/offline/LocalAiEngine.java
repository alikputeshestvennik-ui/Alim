package com.blackbox.offline;

import android.content.Context;
import java.io.File;

/**
 * Fully local Whisper + Qwen engine bridge.
 * Application has NO android.permission.INTERNET.
 */
public class LocalAiEngine {
    private final Context app;
    private static volatile boolean whisperLoaded = false;
    private static volatile boolean llmLoaded = false;
    private static volatile boolean attempted = false;

    public LocalAiEngine(Context c) {
        this.app = c.getApplicationContext();
    }

    private static synchronized void ensureNative() {
        if (!attempted) {
            attempted = true;
            try {
                System.loadLibrary("blackbox_ai");
                whisperLoaded = true;
            } catch (Throwable t) {
                whisperLoaded = false;
            }

            try {
                System.loadLibrary("blackbox_llm");
                llmLoaded = true;
            } catch (Throwable ignored) {
                llmLoaded = false;
            }
        }
    }

    public boolean whisperReady() {
        ensureNative();
        return whisperLoaded && ModelManager.installed(app, ModelManager.WHISPER);
    }

    public boolean qwenReady() {
        ensureNative();
        return llmLoaded && ModelManager.installed(app, ModelManager.LLM);
    }

    public boolean ready() {
        return whisperReady();
    }

    public String transcribe(String path) throws Exception {
        if (!ModelManager.installed(app, ModelManager.WHISPER)) {
            throw new IllegalStateException("Импортируй ggml-base.bin в разделе AI-модели.");
        }
        ensureNative();
        if (!whisperLoaded) {
            throw new IllegalStateException("Нативная библиотека whisper (blackbox_ai) не загружена.");
        }
        File model = ModelManager.file(app, ModelManager.WHISPER);
        return nativeTranscribePcm(PcmDecoder.decode16kMono(path), model.getAbsolutePath());
    }

    public String answer(String question, String context) throws Exception {
        if (qwenReady()) {
            String p = "<|im_start|>system\nТы офлайн-помощник дневника. Отвечай только по приведённым записям. Отвечай кратко на русском.<|im_end|>\n<|im_start|>user\nЗаписи:\n"
                    + context + "\n\nВопрос: " + question + "<|im_end|>\n<|im_start|>assistant\n";
            return nativeGenerate(p, ModelManager.file(app, ModelManager.LLM).getAbsolutePath(), 220);
        }
        return "Локальный LLM-движок Qwen находится в разработке (Этап 2). Используйте поиск по ключевым словам на экране дневника.";
    }

    public String summarize(String context) throws Exception {
        return answer("Сделай краткие итоги этого периода: события, задачи и важное.", context);
    }

    private native String nativeTranscribePcm(float[] pcm, String whisperModel);
    private native String nativeGenerate(String prompt, String model, int maxTokens);
}
