package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
import java.text.*;
import java.util.*;

/**
 * Foreground local microphone service with Enhanced VAD (Adaptive noise floor + RMS tracking).
 * Silences >= 2s or 10 min trigger automatic WAV saving and Whisper queueing.
 */
public class RecordingService extends Service {
    public static final String START = "com.blackbox.offline.START_RECORDING";
    public static final String STOP = "com.blackbox.offline.STOP_RECORDING";
    public static final String STATE = "com.blackbox.offline.RECORDING_STATE";
    public static final String ENTRIES = "com.blackbox.offline.ENTRIES";

    static final int RATE = 16000;
    static final int FRAME = 1024;
    static final long QUIET = 2000;
    static final long MAX = 600000;

    // Enhanced VAD: dynamic adaptive noise floor
    private double noiseFloor = 350.0;
    private static final double ALPHA_NOISE = 0.05; // adaptation rate
    private static final double VAD_RATIO = 2.2;    // SNR multiplier for speech trigger

    private AudioRecord mic;
    private Thread worker;
    private volatile boolean active;
    private volatile boolean saving;
    private ByteArrayOutputStream clip;
    private long began;
    private long lastVoice;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("rec", "Blackbox recording", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Автономная фоновая запись");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String action = i == null ? "" : i.getAction();
        if (START.equals(action) && !active) start();
        if (STOP.equals(action)) stop();
        return START_NOT_STICKY;
    }

    void start() {
        try {
            Intent si = new Intent(this, RecordingService.class).setAction(STOP);
            PendingIntent pi = PendingIntent.getService(this, 1, si, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, "rec")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Blackbox: фоновая запись")
                    .setContentText("Микрофон активен · Обработка на устройстве")
                    .setOngoing(true)
                    .addAction(new Notification.Action.Builder(null, "Остановить", pi).build())
                    .build();

            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(701, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(701, n);
            }

            int b = Math.max(AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), FRAME * 4);
            mic = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, b);
            mic.startRecording();
            active = true;
            state(true);

            worker = new Thread(this::loop);
            worker.start();
        } catch (Exception x) {
            stop();
        }
    }

    void loop() {
        short[] f = new short[FRAME];
        while (active) {
            int n = mic.read(f, 0, FRAME);
            if (n <= 0) continue;

            long sumSq = 0;
            for (int i = 0; i < n; i++) {
                sumSq += (long) f[i] * f[i];
            }
            double currentRms = Math.sqrt(sumSq / (double) n);

            // Adaptive VAD: adjust baseline noise floor when quiet
            if (!saving && currentRms < noiseFloor * 1.5) {
                noiseFloor = (1.0 - ALPHA_NOISE) * noiseFloor + ALPHA_NOISE * currentRms;
                if (noiseFloor < 150.0) noiseFloor = 150.0;
            }

            // Speech detected if RMS significantly exceeds local environmental noise floor
            double threshold = Math.max(500.0, noiseFloor * VAD_RATIO);
            boolean voice = currentRms >= threshold;
            long now = System.currentTimeMillis();

            if (!saving && voice) {
                saving = true;
                clip = new ByteArrayOutputStream();
                began = lastVoice = now;
            }

            if (saving) {
                for (int i = 0; i < n; i++) {
                    clip.write(f[i] & 255);
                    clip.write((f[i] >> 8) & 255);
                }
                if (voice) {
                    lastVoice = now;
                }
                if (now - lastVoice >= QUIET || now - began >= MAX) {
                    close();
                }
            }
        }
    }

    synchronized void close() {
        if (!saving) return;
        saving = false;
        try {
            byte[] p = clip.toByteArray();
            // Ignore tiny noises less than 0.7 sec
            if (p.length < (int)(RATE * 1.4)) return;

            File d = new File(getExternalFilesDir(null), "audio");
            d.mkdirs();
            String id = UUID.randomUUID().toString();
            File out = new File(d, id + ".wav");
            wav(out, p);

            long durationSec = Math.max(1, p.length / (RATE * 2));
            String timeStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
            Entry e = new Entry(id, out.getPath(), timeStr, durationSec, "", "", "Заметки");

            new EntryStore(this).add(e);
            AutoTranscriber.enqueue(this, e);
            RetentionManager.clean(this);
            sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
        } catch (Exception ignored) {}
    }

    void wav(File f, byte[] p) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("RIFF".getBytes());
            le(o, 36 + p.length);
            o.write("WAVEfmt ".getBytes());
            le(o, 16);
            o.write(new byte[]{1, 0, 1, 0});
            le(o, RATE);
            le(o, RATE * 2);
            o.write(new byte[]{2, 0, 16, 0});
            o.write("data".getBytes());
            le(o, p.length);
            o.write(p);
        }
    }

    void le(OutputStream o, int n) throws Exception {
        o.write(n);
        o.write(n >> 8);
        o.write(n >> 16);
        o.write(n >> 24);
    }

    void stop() {
        active = false;
        close();
        if (mic != null) {
            try { mic.stop(); } catch (Exception ignored) {}
            mic.release();
            mic = null;
        }
        stopForeground(true);
        state(false);
        stopSelf();
    }

    void state(boolean x) {
        sendBroadcast(new Intent(STATE).setPackage(getPackageName()).putExtra("active", x));
    }

    @Override
    public android.os.IBinder onBind(Intent x) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (active) stop();
        super.onDestroy();
    }
}
