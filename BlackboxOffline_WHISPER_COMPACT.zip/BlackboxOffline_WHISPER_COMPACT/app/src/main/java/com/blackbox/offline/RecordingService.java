package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
import java.text.*;
import java.util.*;

/**
 * Foreground local microphone service with Robust Dual-Stage VAD (Energy + ZCR + Attack Confirmation).
 * Discards transient noises (clicks, door slams, rustles) and only records real speech.
 * Detects voice commands to stop background listening.
 */
public class RecordingService extends Service {
    public static final String START = "com.blackbox.offline.START_RECORDING";
    public static final String STOP = "com.blackbox.offline.STOP_RECORDING";
    public static final String STATE = "com.blackbox.offline.RECORDING_STATE";
    public static final String ENTRIES = "com.blackbox.offline.ENTRIES";

    static final int RATE = 16000;
    static final int FRAME = 1024; // 64 ms per frame
    static final long QUIET_TIMEOUT_MS = 1500; // 1.5s silence triggers phrase end
    static final long MAX_CLIP_MS = 600000; // 10 min max

    // VAD Parameters calibrated for real-world speech vs noise
    private static final double MIN_VOICE_RMS = 850.0;     // Minimum acoustic energy threshold
    private static final double NOISE_ADAPT_ALPHA = 0.03;  // Background noise tracking speed
    private static final double VAD_SNR_RATIO = 2.4;       // Must exceed noise floor by 2.4x
    private static final int MIN_CONSECUTIVE_VOICED = 3;   // ~200ms sustained speech required to start
    private static final int PRE_ROLL_FRAMES = 4;          // 256ms ring buffer to preserve first syllable

    private double noiseFloor = 350.0;
    private AudioRecord mic;
    private Thread worker;
    public static volatile boolean isRecordingActive = false;
    private volatile boolean active;
    private volatile boolean saving;
    private ByteArrayOutputStream clip;
    private long began;
    private long lastVoiceTime;

    private int totalFramesInClip = 0;
    private int voicedFramesInClip = 0;

    // Pre-roll ring buffer
    private final byte[][] preRoll = new byte[PRE_ROLL_FRAMES][FRAME * 2];
    private int preRollIndex = 0;
    private int preRollCount = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("rec", "Blackbox recording", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Автономная фоновая запись");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String action = i == null ? "" : i.getAction();
        if (START.equals(action) && !active) start();
        if (STOP.equals(action)) stop();
        return START_NOT_STICKY;
    }

    void start() {
        try {
            Intent si = new Intent(this, RecordingService.class).setAction(STOP);
            PendingIntent pi = PendingIntent.getService(this, 1, si, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, "rec")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Blackbox")
                    .setContentText("Фоновое распознавание активно · «Блэкбокс, стоп» для отключения")
                    .setOngoing(true)
                    .addAction(new Notification.Action.Builder(null, "Остановить", pi).build())
                    .build();

            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(701, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(701, n);
            }

            int b = Math.max(AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), FRAME * 4);
            mic = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, b);
            mic.startRecording();
            active = true;
            state(true);

            worker = new Thread(this::loop);
            worker.start();
        } catch (Exception x) {
            stop();
        }
    }

    void loop() {
        short[] f = new short[FRAME];
        byte[] frameBytes = new byte[FRAME * 2];
        int consecutiveVoiced = 0;

        while (active) {
            int n = mic.read(f, 0, FRAME);
            if (n <= 0) continue;

            // Convert to bytes & measure energy and zero crossings
            long sumSq = 0;
            int zcr = 0;
            for (int i = 0; i < n; i++) {
                short val = f[i];
                sumSq += (long) val * val;
                frameBytes[i * 2] = (byte) (val & 255);
                frameBytes[i * 2 + 1] = (byte) ((val >> 8) & 255);
                if (i > 0 && ((f[i] >= 0 && f[i - 1] < 0) || (f[i] < 0 && f[i - 1] >= 0))) {
                    zcr++;
                }
            }

            double currentRms = Math.sqrt(sumSq / (double) n);

            // Dynamic noise floor adaptation during silence
            if (!saving && currentRms < noiseFloor * 1.5) {
                noiseFloor = (1.0 - NOISE_ADAPT_ALPHA) * noiseFloor + NOISE_ADAPT_ALPHA * currentRms;
                if (noiseFloor < 120.0) noiseFloor = 120.0;
            }

            // Speech detector: Energy threshold + Vocal Frequency ZCR band (15 to 240 crossings)
            double requiredThreshold = Math.max(MIN_VOICE_RMS, noiseFloor * VAD_SNR_RATIO);
            boolean isVoiced = (currentRms >= requiredThreshold) && (zcr >= 15 && zcr <= 240);

            long now = System.currentTimeMillis();

            if (!saving) {
                // Store in ring buffer for pre-roll
                System.arraycopy(frameBytes, 0, preRoll[preRollIndex], 0, frameBytes.length);
                preRollIndex = (preRollIndex + 1) % PRE_ROLL_FRAMES;
                if (preRollCount < PRE_ROLL_FRAMES) preRollCount++;

                if (isVoiced) {
                    consecutiveVoiced++;
                    if (consecutiveVoiced >= MIN_CONSECUTIVE_VOICED) {
                        // Confirmed continuous human speech! Trigger recording
                        saving = true;
                        clip = new ByteArrayOutputStream();
                        began = lastVoiceTime = now;
                        totalFramesInClip = 0;
                        voicedFramesInClip = consecutiveVoiced;

                        // Dump pre-roll buffer to avoid clipping first syllable
                        int startIdx = (preRollIndex - preRollCount + PRE_ROLL_FRAMES) % PRE_ROLL_FRAMES;
                        for (int i = 0; i < preRollCount; i++) {
                            int idx = (startIdx + i) % PRE_ROLL_FRAMES;
                            clip.write(preRoll[idx], 0, preRoll[idx].length);
                            totalFramesInClip++;
                        }
                    }
                } else {
                    consecutiveVoiced = 0;
                }
            } else {
                // Recording in progress
                totalFramesInClip++;
                if (isVoiced) {
                    voicedFramesInClip++;
                    lastVoiceTime = now;
                }

                clip.write(frameBytes, 0, frameBytes.length);

                // Early cancellation: if after 1.2 sec (< 19 frames) there are almost no voiced frames,
                // it was a momentary false alarm (single door bang or chair creak). Cancel immediately!
                if (totalFramesInClip >= 19 && voicedFramesInClip < 4) {
                    saving = false;
                    clip = null;
                    consecutiveVoiced = 0;
                    continue;
                }

                // Normal finish on quiet or max time
                if (now - lastVoiceTime >= QUIET_TIMEOUT_MS || now - began >= MAX_CLIP_MS) {
                    close();
                    consecutiveVoiced = 0;
                }
            }
        }
    }

    synchronized void close() {
        if (!saving || clip == null) return;
        saving = false;
        try {
            byte[] p = clip.toByteArray();
            clip = null;

            // Strict quality check: Discard if voiced speech was less than ~600 ms or < 18% of clip
            if (p.length < (int) (RATE * 1.5) || voicedFramesInClip < 8) {
                return;
            }

            File d = new File(getExternalFilesDir(null), "audio");
            d.mkdirs();
            String id = UUID.randomUUID().toString();
            File out = new File(d, id + ".wav");
            wav(out, p);

            long durationSec = Math.max(1, p.length / (RATE * 2));
            String timeStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
            Entry e = new Entry(id, out.getPath(), timeStr, durationSec, "", "", "Заметки");

            new EntryStore(this).add(e);
            AutoTranscriber.enqueue(this, e);
            RetentionManager.clean(this);
            sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
        } catch (Exception ignored) {}
    }

    void wav(File f, byte[] p) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("RIFF".getBytes());
            le(o, 36 + p.length);
            o.write("WAVEfmt ".getBytes());
            le(o, 16);
            o.write(new byte[]{1, 0, 1, 0});
            le(o, RATE);
            le(o, RATE * 2);
            o.write(new byte[]{2, 0, 16, 0});
            o.write("data".getBytes());
            le(o, p.length);
            o.write(p);
        }
    }

    void le(OutputStream o, int n) throws Exception {
        o.write(n);
        o.write(n >> 8);
        o.write(n >> 16);
        o.write(n >> 24);
    }

    void stop() {
        active = false;
        close();
        if (mic != null) {
            try { mic.stop(); } catch (Exception ignored) {}
            mic.release();
            mic = null;
        }
        stopForeground(true);
        state(false);
        stopSelf();
    }

    void state(boolean x) {
        isRecordingActive = x;
        sendBroadcast(new Intent(STATE).setPackage(getPackageName()).putExtra("active", x));
        try {
            BlackboxWidgetProvider.updateAllWidgets(this, x);
        } catch (Throwable ignored) {}
    }

    @Override
    public android.os.IBinder onBind(Intent x) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (active) stop();
        super.onDestroy();
    }
}
