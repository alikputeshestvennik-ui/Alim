package com.blackbox.offline;
import android.app.*; import android.os.*; import android.graphics.*; import android.widget.*; import java.util.*;
/** Local retrieval screen. It never sends diary text over the network. */
public class AskDiaryActivity extends Activity {
  public void onCreate(Bundle b) {
    super.onCreate(b);
    LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(30,35,30,30); l.setBackgroundColor(0xff0b0c0d);
    l.addView(t("Спросить дневник",28));
    EditText q=new EditText(this); q.setHint("Например: Что было 14 мая?"); q.setTextColor(Color.WHITE); q.setHintTextColor(0xffaaaaaa); l.addView(q);
    Button ask=new Button(this); ask.setText("Найти в дневнике"); l.addView(ask);
    TextView out=t("Поиск выполняется только по локальным расшифровкам.",15); l.addView(out);
    ask.setOnClickListener(v->{
      String query=q.getText().toString().toLowerCase(); StringBuilder r=new StringBuilder();
      for(Entry e:new EntryStore(this).all()) {
        String all=(e.created+" "+e.transcript).toLowerCase();
        boolean hit=e.important || (query.length()>0 && (query.contains(e.created.substring(0,10)) || words(query,all)));
        if(hit && !e.transcript.isEmpty()) r.append(e.important?"★ ":"• ").append(e.created).append(": ").append(e.transcript).append("\n\n");
      }
      out.setText(r.length()==0?"Подходящих готовых записей не найдено.":r.toString());
    });
    setContentView(l);
  }
  boolean words(String q,String s){for(String x:q.split("[^а-яa-z0-9]+"))if(x.length()>3&&s.contains(x))return true;return false;}
  TextView t(String x,int z){TextView v=new TextView(this);v.setText(x);v.setTextSize(z);v.setTextColor(Color.WHITE);v.setPadding(0,12,0,12);return v;}
}
