package com.blackbox.offline;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class AskDiaryActivity extends Activity {
    private EditText queryInput;
    private TextView resultText;
    private Button copyBtn;
    private String searchOutput = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        root.setPadding(padH, padV, padH, padV);

        // Header
        root.addView(UI.createHeader(this, "Поиск по дневнику", "Локальный полнотекстовый поиск (Стемминг / Fuzzy)", true));

        // Search Card
        LinearLayout searchCard = UI.createCard(this);

        TextView labelSearch = new TextView(this);
        labelSearch.setText("ПОИСКОВЫЙ ЗАПРОС");
        labelSearch.setTextColor(UI.COLOR_TEXT_SUBTLE);
        labelSearch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        labelSearch.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        labelSearch.setPadding(0, 0, 0, UI.dp(this, 8));
        searchCard.addView(labelSearch);

        queryInput = UI.inputField(this, "Ключевое слово, задача, имя или дата...");
        searchCard.addView(queryInput);

        Button searchBtn = UI.primaryButton(this, "Найти в сохранённых записях");
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.topMargin = UI.dp(this, 12);
        searchBtn.setOnClickListener(v -> performSearch());
        searchCard.addView(searchBtn, btnLp);

        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(-1, -2);
        scLp.bottomMargin = UI.dp(this, 16);
        root.addView(searchCard, scLp);

        // Results Card
        LinearLayout resCard = UI.createCard(this);
        resCard.setBackground(UI.shape(UI.COLOR_SURFACE, UI.COLOR_BORDER, 16, this));

        LinearLayout headRow = new LinearLayout(this);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView resLabel = new TextView(this);
        resLabel.setText("РЕЗУЛЬТАТЫ ПОИСКА");
        resLabel.setTextColor(UI.COLOR_TEXT_ORANGE);
        resLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        resLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        headRow.addView(resLabel);

        copyBtn = UI.secondaryButton(this, "Скопировать");
        copyBtn.setVisibility(Button.GONE);
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(-2, -2);
        cpLp.leftMargin = UI.dp(this, 12);
        copyBtn.setOnClickListener(v -> {
            if (!searchOutput.isEmpty()) {
                UI.copyToClipboard(this, "Поиск по дневнику", searchOutput);
            }
        });
        headRow.addView(copyBtn);

        resCard.addView(headRow);

        resultText = new TextView(this);
        resultText.setText("Введите запрос для поиска по всем расшифрованным заметкам.");
        resultText.setTextColor(UI.COLOR_TEXT_MUTED);
        resultText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        resultText.setLineSpacing(UI.dp(this, 4), 1.0f);
        resultText.setPadding(0, UI.dp(this, 12), 0, 0);
        resCard.addView(resultText);

        root.addView(resCard);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void performSearch() {
        String raw = queryInput.getText().toString().trim().toLowerCase();
        if (raw.isEmpty()) {
            resultText.setText("Введите слово или фразу для поиска.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
            return;
        }

        // Stem tokens (prefixes >= 3 chars for Russian morphology matching)
        String[] words = raw.split("\\s+");
        List<String> stems = new ArrayList<>();
        for (String w : words) {
            if (w.length() >= 4) {
                stems.add(w.substring(0, Math.min(w.length() - 1, 6)));
            } else {
                stems.add(w);
            }
        }

        StringBuilder out = new StringBuilder();
        int matches = 0;

        for (Entry e : new EntryStore(this).all()) {
            if (e.transcript == null || e.transcript.trim().isEmpty()) continue;
            String text = (e.created + " " + e.category + " " + e.transcript).toLowerCase();

            boolean matchAllStems = true;
            for (String stem : stems) {
                if (!text.contains(stem)) {
                    matchAllStems = false;
                    break;
                }
            }

            if (matchAllStems) {
                matches++;
                out.append(e.important ? "★ [ВАЖНО] " : "• ")
                   .append("[").append(e.category != null ? e.category : "Заметка").append("] ")
                   .append(e.created).append("\n")
                   .append(e.transcript.trim())
                   .append("\n\n");
            }
        }

        if (matches == 0) {
            searchOutput = "";
            resultText.setText("По запросу «" + queryInput.getText().toString().trim() + "» совпадений не найдено.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
        } else {
            searchOutput = "Найдено фрагментов: " + matches + "\n\n" + out.toString();
            resultText.setText(searchOutput);
            resultText.setTextColor(UI.COLOR_TEXT_PRIMARY);
            copyBtn.setVisibility(Button.VISIBLE);
        }
    }
}
