package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;

public class ModelsActivity extends Activity {
    private static final int REQ_WHISPER = 1;
    private static final int REQ_LLM = 2;
    private LinearLayout container;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        draw();
    }

    private void draw() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        container.setPadding(padH, padV, padH, padV);

        // Header
        container.addView(UI.createHeader(this, "AI-модели", "Локальные нейросети без интернета", true));

        // Model 1: Whisper Card
        boolean whisperInstalled = ModelManager.installed(this, ModelManager.WHISPER);
        String whisperSizeStr = ModelManager.size(this, ModelManager.WHISPER);

        LinearLayout cardW = UI.createCard(this);
        if (whisperInstalled) {
            cardW.setBackground(UI.shape(0xFF141A14, 0xFF244A28, 16, this));
        }

        LinearLayout topW = new LinearLayout(this);
        topW.setOrientation(LinearLayout.HORIZONTAL);
        topW.setGravity(Gravity.CENTER_VERTICAL);

        TextView tagW = UI.badge(this, "STT (РЕЧЬ В ТЕКСТ)", UI.COLOR_ORANGE, UI.COLOR_ORANGE_DIM);
        topW.addView(tagW);

        View sp1 = new View(this);
        topW.addView(sp1, new LinearLayout.LayoutParams(0, 1, 1.0f));

        TextView stW = UI.badge(this,
                whisperInstalled ? "● АКТИВНА" : "○ НЕ УСТАНОВЛЕНА",
                whisperInstalled ? UI.COLOR_GREEN : UI.COLOR_RED,
                whisperInstalled ? UI.COLOR_GREEN_BG : UI.COLOR_RED_BG);
        topW.addView(stW);
        cardW.addView(topW);

        TextView titleW = new TextView(this);
        titleW.setText("Whisper Base / Small");
        titleW.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        titleW.setTextColor(UI.COLOR_TEXT_TITLE);
        titleW.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        titleW.setPadding(0, UI.dp(this, 10), 0, UI.dp(this, 4));
        cardW.addView(titleW);

        TextView descW = new TextView(this);
        descW.setText("Локальный движок whisper.cpp для автоматической расшифровки речи на русском языке. Работает на CPU телефона.");
        descW.setTextColor(UI.COLOR_TEXT_MUTED);
        descW.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        cardW.addView(descW);

        TextView sizeW = new TextView(this);
        sizeW.setText("Статус: " + whisperSizeStr);
        sizeW.setTextColor(whisperInstalled ? UI.COLOR_TEXT_ORANGE : UI.COLOR_TEXT_SUBTLE);
        sizeW.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        sizeW.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        sizeW.setPadding(0, UI.dp(this, 8), 0, UI.dp(this, 14));
        cardW.addView(sizeW);

        Button btnW = UI.primaryButton(this, whisperInstalled ? "Заменить модель Whisper (.bin)" : "Импортировать ggml-base.bin");
        btnW.setOnClickListener(v -> pickFile(REQ_WHISPER));
        cardW.addView(btnW);

        LinearLayout.LayoutParams clp1 = new LinearLayout.LayoutParams(-1, -2);
        clp1.bottomMargin = UI.dp(this, 16);
        container.addView(cardW, clp1);

        // Model 2: Qwen LLM Card
        boolean llmInstalled = ModelManager.installed(this, ModelManager.LLM);
        String llmSizeStr = ModelManager.size(this, ModelManager.LLM);

        LinearLayout cardQ = UI.createCard(this);

        LinearLayout topQ = new LinearLayout(this);
        topQ.setOrientation(LinearLayout.HORIZONTAL);
        topQ.setGravity(Gravity.CENTER_VERTICAL);

        TextView tagQ = UI.badge(this, "LLM (ИНТЕЛЛЕКТ)", UI.COLOR_TEXT_MUTED, 0xFF1B2028);
        topQ.addView(tagQ);

        View sp2 = new View(this);
        topQ.addView(sp2, new LinearLayout.LayoutParams(0, 1, 1.0f));

        TextView stQ = UI.badge(this, "ЭТАП 2: В РАЗРАБОТКЕ", UI.COLOR_ORANGE_LIGHT, 0x33F47721);
        topQ.addView(stQ);
        cardQ.addView(topQ);

        TextView titleQ = new TextView(this);
        titleQ.setText("Qwen 2.5 / llama.cpp");
        titleQ.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        titleQ.setTextColor(UI.COLOR_TEXT_TITLE);
        titleQ.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        titleQ.setPadding(0, UI.dp(this, 10), 0, UI.dp(this, 4));
        cardQ.addView(titleQ);

        TextView descQ = new TextView(this);
        descQ.setText("Нейросеть для умного саммари и генеративных ответов. Сейчас выборка работает локально по расшифрованным текстам без эмуляции ИИ.");
        descQ.setTextColor(UI.COLOR_TEXT_MUTED);
        descQ.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        cardQ.addView(descQ);

        TextView sizeQ = new TextView(this);
        sizeQ.setText("Файл qwen.gguf: " + llmSizeStr);
        sizeQ.setTextColor(llmInstalled ? UI.COLOR_TEXT_ORANGE : UI.COLOR_TEXT_SUBTLE);
        sizeQ.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        sizeQ.setPadding(0, UI.dp(this, 8), 0, UI.dp(this, 14));
        cardQ.addView(sizeQ);

        Button btnQ = UI.secondaryButton(this, "Импортировать Qwen GGUF в запас");
        btnQ.setOnClickListener(v -> pickFile(REQ_LLM));
        cardQ.addView(btnQ);

        LinearLayout.LayoutParams clp2 = new LinearLayout.LayoutParams(-1, -2);
        clp2.bottomMargin = UI.dp(this, 16);
        container.addView(cardQ, clp2);

        // Security Notice Card
        LinearLayout notice = UI.createCard(this);
        notice.setBackground(UI.shape(0xFF0F1116, UI.COLOR_BORDER, 14, this));

        TextView noticeTitle = new TextView(this);
        noticeTitle.setText("🔒 Локальное хранение моделей");
        noticeTitle.setTextColor(UI.COLOR_TEXT_TITLE);
        noticeTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        noticeTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        notice.addView(noticeTitle);

        TextView noticeText = new TextView(this);
        noticeText.setText("Импортированные модели копируются в изолированную директорию приложения. Они никогда не передаются по сети и доступны только Blackbox.");
        noticeText.setTextColor(UI.COLOR_TEXT_MUTED);
        noticeText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        noticeText.setPadding(0, UI.dp(this, 6), 0, 0);
        notice.addView(noticeText);

        container.addView(notice);

        scroll.addView(container);
        setContentView(scroll);
    }

    private void pickFile(int reqCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, reqCode);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        Toast.makeText(this, "Копирование модели во внутреннее хранилище...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            try {
                String target = req == REQ_WHISPER ? ModelManager.WHISPER : ModelManager.LLM;
                ModelManager.importFile(this, uri, target);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Модель успешно установлена!", Toast.LENGTH_SHORT).show();
                    draw();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Ошибка импорта: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }
}
