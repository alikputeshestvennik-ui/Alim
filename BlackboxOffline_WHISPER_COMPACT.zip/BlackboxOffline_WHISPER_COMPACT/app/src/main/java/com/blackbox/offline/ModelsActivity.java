package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;

public class ModelsActivity extends Activity {
    private static final int REQ_WHISPER = 1;
    private static final int REQ_LLM = 2;
    private LinearLayout container;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        draw();
    }

    private void draw() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        container.setPadding(padH, padV, padH, padV);

        // Header
        container.addView(UI.createHeader(this, "AI-модели", "Автономные локальные нейросети", true));

        // Model 1: Whisper Card
        boolean whisperInstalled = ModelManager.installed(this, ModelManager.WHISPER);
        String whisperSizeStr = ModelManager.size(this, ModelManager.WHISPER);

        LinearLayout cardW = UI.createCard(this);
        if (whisperInstalled) {
            cardW.setBackground(UI.shape(0xFF141A14, 0xFF244A28, 16, this));
        }

        LinearLayout topW = new LinearLayout(this);
        topW.setOrientation(LinearLayout.HORIZONTAL);
        topW.setGravity(Gravity.CENTER_VERTICAL);

        TextView tagW = UI.badge(this, "STT (РЕЧЬ В ТЕКСТ)", UI.COLOR_ORANGE, UI.COLOR_ORANGE_DIM);
        topW.addView(tagW);

        View sp1 = new View(this);
        topW.addView(sp1, new LinearLayout.LayoutParams(0, 1, 1.0f));

        TextView stW = UI.badge(this,
                whisperInstalled ? "АКТИВНА" : "НЕ УСТАНОВЛЕНА",
                whisperInstalled ? UI.COLOR_GREEN : UI.COLOR_RED,
                whisperInstalled ? UI.COLOR_GREEN_BG : 0x22EF4444);
        topW.addView(stW);
        cardW.addView(topW);

        TextView titleW = new TextView(this);
        titleW.setText("Whisper Base / Small");
        titleW.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        titleW.setTextColor(UI.COLOR_TEXT_TITLE);
        titleW.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        titleW.setPadding(0, UI.dp(this, 10), 0, UI.dp(this, 4));
        cardW.addView(titleW);

        TextView descW = new TextView(this);
        descW.setText("Локальный движок whisper.cpp для автоматической расшифровки речи на русском языке.");
        descW.setTextColor(UI.COLOR_TEXT_MUTED);
        descW.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        cardW.addView(descW);

        TextView sizeW = new TextView(this);
        sizeW.setText("Статус: " + whisperSizeStr);
        sizeW.setTextColor(whisperInstalled ? UI.COLOR_TEXT_ORANGE : UI.COLOR_TEXT_SUBTLE);
        sizeW.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        sizeW.setPadding(0, UI.dp(this, 8), 0, UI.dp(this, 14));
        cardW.addView(sizeW);

        Button btnW = UI.primaryButton(this, whisperInstalled ? "Заменить ggml-base.bin" : "Импортировать ggml-base.bin");
        btnW.setOnClickListener(v -> pickFile(REQ_WHISPER));
        cardW.addView(btnW);

        LinearLayout.LayoutParams clp1 = new LinearLayout.LayoutParams(-1, -2);
        clp1.bottomMargin = UI.dp(this, 16);
        container.addView(cardW, clp1);

        // Model 2: Qwen LLM Card
        boolean llmInstalled = ModelManager.installed(this, ModelManager.LLM);
        String llmSizeStr = ModelManager.size(this, ModelManager.LLM);

        LinearLayout cardQ = UI.createCard(this);
        if (llmInstalled) {
            cardQ.setBackground(UI.shape(0xFF141A14, 0xFF244A28, 16, this));
        }

        LinearLayout topQ = new LinearLayout(this);
        topQ.setOrientation(LinearLayout.HORIZONTAL);
        topQ.setGravity(Gravity.CENTER_VERTICAL);

        TextView tagQ = UI.badge(this, "LLM (ИНТЕЛЛЕКТ)", UI.COLOR_ORANGE, UI.COLOR_ORANGE_DIM);
        topQ.addView(tagQ);

        View sp2 = new View(this);
        topQ.addView(sp2, new LinearLayout.LayoutParams(0, 1, 1.0f));

        TextView stQ = UI.badge(this,
                llmInstalled ? "АКТИВНА" : "ГОТОВА К ИМПОРТУ",
                llmInstalled ? UI.COLOR_GREEN : UI.COLOR_TEXT_MUTED,
                llmInstalled ? UI.COLOR_GREEN_BG : 0xFF1F242D);
        topQ.addView(stQ);
        cardQ.addView(topQ);

        TextView titleQ = new TextView(this);
        titleQ.setText("Qwen 2.5 Intelligence Engine");
        titleQ.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        titleQ.setTextColor(UI.COLOR_TEXT_TITLE);
        titleQ.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        titleQ.setPadding(0, UI.dp(this, 10), 0, UI.dp(this, 4));
        cardQ.addView(titleQ);

        TextView descQ = new TextView(this);
        descQ.setText("Автономный когнитивный модуль: структуризация дня, задачи, встречи, ключевые выводы и смысловые ответы.");
        descQ.setTextColor(UI.COLOR_TEXT_MUTED);
        descQ.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        cardQ.addView(descQ);

        TextView sizeQ = new TextView(this);
        sizeQ.setText("Статус: " + llmSizeStr);
        sizeQ.setTextColor(llmInstalled ? UI.COLOR_TEXT_ORANGE : UI.COLOR_TEXT_SUBTLE);
        sizeQ.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        sizeQ.setPadding(0, UI.dp(this, 8), 0, UI.dp(this, 14));
        cardQ.addView(sizeQ);

        Button btnQ = UI.secondaryButton(this, llmInstalled ? "Заменить qwen.gguf" : "Импортировать Qwen GGUF");
        btnQ.setOnClickListener(v -> pickFile(REQ_LLM));
        cardQ.addView(btnQ);

        LinearLayout.LayoutParams clp2 = new LinearLayout.LayoutParams(-1, -2);
        clp2.bottomMargin = UI.dp(this, 16);
        container.addView(cardQ, clp2);

        scroll.addView(container);
        setContentView(scroll);
    }

    private void pickFile(int reqCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, reqCode);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        Toast.makeText(this, "Копирование модели во внутреннее хранилище...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            try {
                String target = req == REQ_WHISPER ? ModelManager.WHISPER : ModelManager.LLM;
                ModelManager.importFile(this, uri, target);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Модель успешно установлена!", Toast.LENGTH_SHORT).show();
                    draw();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Ошибка импорта: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }
}
