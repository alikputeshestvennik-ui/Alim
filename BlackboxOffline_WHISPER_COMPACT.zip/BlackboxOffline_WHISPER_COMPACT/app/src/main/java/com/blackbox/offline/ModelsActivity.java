package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class ModelsActivity extends Activity {
    static final int W = 1, Q = 2;
    LinearLayout l;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        draw();
    }

    void draw() {
        ScrollView s = new ScrollView(this);
        l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(32, 35, 32, 32);
        l.setBackgroundColor(0xff0b0c0d);
        l.addView(t("AI-модели", 28, Color.WHITE));
        l.addView(t("Whisper: " + ModelManager.size(this, ModelManager.WHISPER), 16, Color.WHITE));
        Button w = b("Импортировать ggml-base.bin");
        l.addView(w);
        w.setOnClickListener(v -> pick(W));
        l.addView(t("Qwen: " + ModelManager.size(this, ModelManager.LLM), 16, Color.WHITE));
        Button q = b("Импортировать Qwen .gguf");
        l.addView(q);
        q.setOnClickListener(v -> pick(Q));
        l.addView(t("Модели копируются только в локальное хранилище Blackbox. Интернет не используется.", 14, 0xffb7b1a8));
        s.addView(l);
        setContentView(s);
    }

    void pick(int n) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, n);
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (c != RESULT_OK || d == null || d.getData() == null) return;
        Toast.makeText(this, "Копирование модели...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                ModelManager.importFile(this, d.getData(), r == W ? ModelManager.WHISPER : ModelManager.LLM);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Модель успешно установлена", Toast.LENGTH_SHORT).show();
                    draw();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Ошибка импорта: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    TextView t(String x, int z, int c) {
        TextView v = new TextView(this);
        v.setText(x);
        v.setTextSize(z);
        v.setTextColor(c);
        v.setPadding(0, 12, 0, 12);
        return v;
    }

    Button b(String x) {
        Button b = new Button(this);
        b.setText(x);
        b.setAllCaps(false);
        return b;
    }
}
