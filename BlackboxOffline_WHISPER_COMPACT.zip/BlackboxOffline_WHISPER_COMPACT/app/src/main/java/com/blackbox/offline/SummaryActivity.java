package com.blackbox.offline;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class SummaryActivity extends Activity {
    private EditText dateInput;
    private TextView resultText;
    private Button copyBtn;
    private String currentSummary = "";
    private LocalAiEngine aiEngine;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        aiEngine = new LocalAiEngine(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        root.setPadding(padH, padV, padH, padV);

        // Header
        root.addView(UI.createHeader(this, "Итоги дня", "Интеллектуальная сводка Qwen AI", true));

        // Input Card
        LinearLayout inputCard = UI.createCard(this);

        TextView labelDate = new TextView(this);
        labelDate.setText("ДАТА СВОДКИ");
        labelDate.setTextColor(UI.COLOR_TEXT_SUBTLE);
        labelDate.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        labelDate.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        labelDate.setPadding(0, 0, 0, UI.dp(this, 8));
        inputCard.addView(labelDate);

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        dateInput = UI.inputField(this, "Например: " + today);
        dateInput.setText(today);
        inputCard.addView(dateInput);

        Button makeBtn = UI.primaryButton(this, "Сформировать умные итоги дня");
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.topMargin = UI.dp(this, 12);
        makeBtn.setOnClickListener(v -> generateSummary());
        inputCard.addView(makeBtn, btnLp);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = UI.dp(this, 16);
        root.addView(inputCard, cardLp);

        // Result Card
        LinearLayout resultCard = UI.createCard(this);
        resultCard.setBackground(UI.shape(UI.COLOR_SURFACE, UI.COLOR_BORDER, 16, this));

        LinearLayout resHead = new LinearLayout(this);
        resHead.setOrientation(LinearLayout.HORIZONTAL);
        resHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView resTitle = new TextView(this);
        resTitle.setText("РЕЗУЛЬТАТ");
        resTitle.setTextColor(UI.COLOR_TEXT_ORANGE);
        resTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        resTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        resHead.addView(resTitle);

        copyBtn = UI.secondaryButton(this, "Скопировать");
        copyBtn.setVisibility(Button.GONE);
        LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(-2, -2);
        cpLp.leftMargin = UI.dp(this, 12);
        copyBtn.setOnClickListener(v -> {
            if (!currentSummary.isEmpty()) {
                UI.copyToClipboard(this, "Итоги дня", currentSummary);
            }
        });
        resHead.addView(copyBtn);

        resultCard.addView(resHead);

        resultText = new TextView(this);
        resultText.setText("Выберите дату и нажмите кнопку для автоматической структуризации дня.");
        resultText.setTextColor(UI.COLOR_TEXT_MUTED);
        resultText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        resultText.setLineSpacing(UI.dp(this, 4), 1.0f);
        resultText.setPadding(0, UI.dp(this, 12), 0, 0);
        resultCard.addView(resultText);

        root.addView(resultCard);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void generateSummary() {
        String targetDate = dateInput.getText().toString().trim();
        if (targetDate.isEmpty()) {
            targetDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        }

        StringBuilder contextBuilder = new StringBuilder();
        int count = 0;

        for (Entry e : new EntryStore(this).all()) {
            if (e.created != null && e.created.startsWith(targetDate) && e.transcript != null && !e.transcript.trim().isEmpty()) {
                count++;
                String mark = e.important ? "★ " : "• ";
                contextBuilder.append(mark).append(e.created.length() > 11 ? e.created.substring(11) : e.created).append(": ");
                contextBuilder.append(e.transcript.trim()).append("\n\n");
            }
        }

        if (count == 0) {
            currentSummary = "";
            resultText.setText("За дату " + targetDate + " готовых расшифрованных записей не найдено.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
        } else {
            currentSummary = aiEngine.summarize(contextBuilder.toString(), targetDate);
            resultText.setText(currentSummary);
            resultText.setTextColor(UI.COLOR_TEXT_PRIMARY);
            copyBtn.setVisibility(Button.VISIBLE);
        }
    }
}
