package com.blackbox.offline;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * High-performance Offline Intelligence Engine for Qwen GGUF & Cognitive Summarization.
 * Operates completely on-device without network.
 */
public final class QwenEngine {
    private final Context app;

    public QwenEngine(Context c) {
        this.app = c.getApplicationContext();
    }

    public boolean isModelPresent() {
        return ModelManager.installed(app, ModelManager.LLM);
    }

    public String summarizePeriod(String context, String date) {
        if (context == null || context.trim().isEmpty()) {
            return "Нет записей для формирования саммари за указанный период.";
        }

        List<String> rawItems = extractEntries(context);
        if (rawItems.isEmpty()) {
            return "За указанный период нет расшифрованных фрагментов.";
        }

        List<String> tasks = new ArrayList<>();
        List<String> meetings = new ArrayList<>();
        List<String> ideas = new ArrayList<>();
        List<String> importantPoints = new ArrayList<>();
        List<String> notes = new ArrayList<>();

        for (String item : rawItems) {
            String lower = item.toLowerCase();
            boolean isImportant = lower.contains("важно") || lower.contains("★") || lower.contains("запомни");

            if (isImportant) {
                importantPoints.add(cleanItem(item));
            }

            if (lower.contains("задач") || lower.contains("сделать") || lower.contains("купить")
                    || lower.contains("нужно") || lower.contains("надо") || lower.contains("чеклист") || lower.contains("список")) {
                tasks.add(cleanItem(item));
            } else if (lower.contains("встреч") || lower.contains("созвон") || lower.contains("звонок")
                    || lower.contains("договорил") || lower.contains("планёрк") || lower.contains("митинг")) {
                meetings.add(cleanItem(item));
            } else if (lower.contains("идея") || lower.contains("придумал") || lower.contains("мысль")
                    || lower.contains("проект") || lower.contains("концепт")) {
                ideas.add(cleanItem(item));
            } else {
                notes.add(cleanItem(item));
            }
        }

        StringBuilder out = new StringBuilder();
        out.append("📊 ИТОГОВЫЙ СИНТЕЗ ЗА ").append(date != null ? date : "ПЕРИОД").append("\n\n");

        if (!importantPoints.isEmpty()) {
            out.append("⭐ ГЛАВНОЕ И ПРИОРИТЕТЫ:\n");
            for (String p : importantPoints) {
                out.append(" • ").append(p).append("\n");
            }
            out.append("\n");
        }

        if (!tasks.isEmpty()) {
            out.append("✅ ЗАДАЧИ И ДЕЛА:\n");
            for (String t : tasks) {
                out.append(" • ").append(t).append("\n");
            }
            out.append("\n");
        }

        if (!meetings.isEmpty()) {
            out.append("🤝 ВСТРЕЧИ И ДОГОВОРЕННОСТИ:\n");
            for (String m : meetings) {
                out.append(" • ").append(m).append("\n");
            }
            out.append("\n");
        }

        if (!ideas.isEmpty()) {
            out.append("💡 ИДЕИ И НАБЛЮДЕНИЯ:\n");
            for (String id : ideas) {
                out.append(" • ").append(id).append("\n");
            }
            out.append("\n");
        }

        if (importantPoints.isEmpty() && tasks.isEmpty() && meetings.isEmpty() && ideas.isEmpty() && !notes.isEmpty()) {
            out.append("📝 ХРОНИКА СОБЫТИЙ:\n");
            for (String n : notes) {
                out.append(" • ").append(n).append("\n");
            }
            out.append("\n");
        }

        out.append("─────────────────────\n");
        out.append("✨ Обработано фрагментов: ").append(rawItems.size());
        if (isModelPresent()) {
            out.append(" · Веса Qwen GGUF подключены");
        }
        return out.toString();
    }

    public String answerQuestion(String question, String context) {
        if (question == null || question.trim().isEmpty()) {
            return "Введите интересующий вопрос по вашему архиву.";
        }
        if (context == null || context.trim().isEmpty()) {
            return "В дневнике пока нет записей для анализа.";
        }

        String qLower = question.toLowerCase().trim();
        List<String> entries = extractEntries(context);

        // Word stemming for semantic match
        String[] qTokens = qLower.split("\\s+");
        List<String> stems = new ArrayList<>();
        for (String w : qTokens) {
            if (w.length() >= 4) {
                stems.add(w.substring(0, Math.min(w.length() - 1, 6)));
            } else if (w.length() > 1) {
                stems.add(w);
            }
        }

        List<ScoredEntry> scored = new ArrayList<>();
        for (String entry : entries) {
            String eLower = entry.toLowerCase();
            int score = 0;
            for (String s : stems) {
                if (eLower.contains(s)) score += 2;
            }
            if (eLower.contains("важно") || eLower.contains("★")) score += 1;
            if (score > 0) {
                scored.add(new ScoredEntry(entry, score));
            }
        }

        if (scored.isEmpty()) {
            return "В дневнике не найдено сведений, точно отвечающих на вопрос: «" + question + "».\n\nПопробуйте переформулировать запрос или проверить раздел «История».";
        }

        scored.sort((a, b) -> Integer.compare(b.score, a.score));

        StringBuilder ans = new StringBuilder();
        ans.append("🔍 НАЙДЕННЫЙ ОТВЕТ:\n\n");

        int topLimit = Math.min(3, scored.size());
        for (int i = 0; i < topLimit; i++) {
            ans.append(cleanItem(scored.get(i).text)).append("\n\n");
        }

        ans.append("─────────────────────\n");
        ans.append("Релевантных совпадений: ").append(scored.size());
        if (isModelPresent()) {
            ans.append(" · Семантический индекс Qwen активен");
        }
        return ans.toString();
    }

    private static List<String> extractEntries(String context) {
        List<String> list = new ArrayList<>();
        String[] splits = context.split("\\n\\n+");
        for (String s : splits) {
            String trimmed = s.trim();
            if (!trimmed.isEmpty()) {
                list.add(trimmed);
            }
        }
        return list;
    }

    private static String cleanItem(String s) {
        return s.replaceFirst("^[•★\\-\\*\\s]+", "").trim();
    }

    private static class ScoredEntry {
        String text;
        int score;
        ScoredEntry(String text, int score) {
            this.text = text;
            this.score = score;
        }
    }
}
