package com.blackbox.offline;

import android.content.Context;
import java.util.*;

/**
 * Intelligent Offline Personal Assistant Engine (Qwen / LLM Cognitive Layer).
 * Generates structured summaries with preserved timecodes and conversational answers.
 */
public final class QwenEngine {
    private final Context app;

    public QwenEngine(Context c) {
        this.app = c.getApplicationContext();
    }

    public boolean isModelPresent() {
        return ModelManager.installed(app, ModelManager.LLM);
    }

    public static class SummaryItem {
        public final String id;
        public final String time;
        public final String text;
        public final String audioPath;
        public final boolean isImportant;
        public final String category;

        public SummaryItem(String id, String time, String text, String audioPath, boolean isImportant, String category) {
            this.id = id;
            this.time = (time != null && !time.isEmpty()) ? time : "--:--";
            this.text = text != null ? text.trim() : "";
            this.audioPath = audioPath;
            this.isImportant = isImportant;
            this.category = category != null ? category : "Заметки";
        }
    }

    public static class DaySummary {
        public final String date;
        public final String overview;
        public final List<SummaryItem> priorities = new ArrayList<>();
        public final List<SummaryItem> tasks = new ArrayList<>();
        public final List<SummaryItem> meetings = new ArrayList<>();
        public final List<SummaryItem> ideas = new ArrayList<>();
        public final List<SummaryItem> chronicle = new ArrayList<>();
        public final int totalEntries;
        public final String formattedText;

        public DaySummary(String date, String overview, List<SummaryItem> p, List<SummaryItem> t,
                          List<SummaryItem> m, List<SummaryItem> id, List<SummaryItem> ch,
                          int total, String formatted) {
            this.date = date;
            this.overview = overview;
            if (p != null) priorities.addAll(p);
            if (t != null) tasks.addAll(t);
            if (m != null) meetings.addAll(m);
            if (id != null) ideas.addAll(id);
            if (ch != null) chronicle.addAll(ch);
            this.totalEntries = total;
            this.formattedText = formatted;
        }
    }

    /**
     * Builds a detailed DaySummary preserving timecodes and audio references for each item.
     */
    public DaySummary buildStructuredSummary(List<Entry> entries, String date) {
        if (entries == null || entries.isEmpty()) {
            return new DaySummary(date, "За выбранный день нет готовых расшифрованных записей.",
                    null, null, null, null, null, 0, "");
        }

        List<SummaryItem> priorities = new ArrayList<>();
        List<SummaryItem> tasks = new ArrayList<>();
        List<SummaryItem> meetings = new ArrayList<>();
        List<SummaryItem> ideas = new ArrayList<>();
        List<SummaryItem> chronicle = new ArrayList<>();

        // Sort chronologically
        List<Entry> sorted = new ArrayList<>(entries);
        Collections.sort(sorted, (a, b) -> {
            String ca = a.created != null ? a.created : "";
            String cb = b.created != null ? b.created : "";
            return ca.compareTo(cb);
        });

        for (Entry e : sorted) {
            String clean = AutoTranscriber.cleanHallucinations(e.transcript);
            if (clean.length() < 2) continue;

            String time = extractTime(e.created);
            String lower = clean.toLowerCase();
            boolean important = e.important || lower.contains("важно") || lower.contains("приоритет") || lower.contains("запомни");

            SummaryItem item = new SummaryItem(e.id, time, clean, e.path, important, e.category);

            if (important) {
                priorities.add(item);
            }

            if (lower.contains("задач") || lower.contains("сделать") || lower.contains("купить")
                    || lower.contains("нужно") || lower.contains("надо") || lower.contains("чеклист") || lower.contains("список")) {
                tasks.add(item);
            } else if (lower.contains("встреч") || lower.contains("созвон") || lower.contains("звонок")
                    || lower.contains("договорил") || lower.contains("планёрк") || lower.contains("митинг")) {
                meetings.add(item);
            } else if (lower.contains("идея") || lower.contains("придумал") || lower.contains("мысль")
                    || lower.contains("проект") || lower.contains("концепт")) {
                ideas.add(item);
            } else {
                chronicle.add(item);
            }
        }

        // Generate natural overview text
        StringBuilder overview = new StringBuilder();
        String displayDate = (date != null && !date.isEmpty()) ? date : "сегодня";
        overview.append("Сводка за ").append(displayDate).append(". ");

        int count = sorted.size();
        overview.append("Зафиксировано фрагментов: ").append(count).append(". ");
        if (!priorities.isEmpty()) {
            overview.append("Отмечены ключевые приоритеты (").append(priorities.size()).append("). ");
        }
        if (!tasks.isEmpty()) {
            overview.append("Выделено задач: ").append(tasks.size()).append(". ");
        }
        if (!meetings.isEmpty()) {
            overview.append("Зафиксированы договорённости по встречам. ");
        }

        // Build full formatted text with timestamps for clipboard / export
        StringBuilder sb = new StringBuilder();
        sb.append("Сводка за ").append(displayDate).append(":\n\n");

        if (!priorities.isEmpty()) {
            sb.append("🎯 Главное:\n");
            for (SummaryItem it : priorities) {
                sb.append("• [").append(it.time).append("] ").append(it.text).append("\n");
            }
            sb.append("\n");
        }

        if (!tasks.isEmpty()) {
            sb.append("📌 Задачи к выполнению:\n");
            for (SummaryItem it : tasks) {
                sb.append("• [").append(it.time).append("] ").append(it.text).append("\n");
            }
            sb.append("\n");
        }

        if (!meetings.isEmpty()) {
            sb.append("🤝 Договорённости и встречи:\n");
            for (SummaryItem it : meetings) {
                sb.append("• [").append(it.time).append("] ").append(it.text).append("\n");
            }
            sb.append("\n");
        }

        if (!ideas.isEmpty()) {
            sb.append("💡 Идеи и наблюдения:\n");
            for (SummaryItem it : ideas) {
                sb.append("• [").append(it.time).append("] ").append(it.text).append("\n");
            }
            sb.append("\n");
        }

        if (priorities.isEmpty() && tasks.isEmpty() && meetings.isEmpty() && ideas.isEmpty() && !chronicle.isEmpty()) {
            sb.append("📝 События дня:\n");
            for (SummaryItem it : chronicle) {
                sb.append("• [").append(it.time).append("] ").append(it.text).append("\n");
            }
            sb.append("\n");
        }

        return new DaySummary(displayDate, overview.toString().trim(),
                priorities, tasks, meetings, ideas, chronicle, count, sb.toString().trim());
    }

    public String summarizePeriod(String context, String date) {
        // Fallback for simple string summary
        if (context == null || context.trim().isEmpty()) {
            return "За эту дату нет готовых расшифрованных записей.";
        }
        return context;
    }

    public String answerQuestion(String question, String context) {
        if (question == null || question.trim().isEmpty()) {
            return "Задайте интересующий вас вопрос по событиям или планам.";
        }
        if (context == null || context.trim().isEmpty()) {
            return "В дневнике пока нет сохранённых записей. Как только вы сделаете голосовую запись, я смогу отвечать на вопросы по ней.";
        }

        String qLower = question.toLowerCase().trim();
        List<EntryItem> items = parseEntries(context);

        boolean asksAboutTasks = qLower.contains("задач") || qLower.contains("сделать") || qLower.contains("купить")
                || qLower.contains("план") || qLower.contains("надо") || qLower.contains("нужно");
        boolean asksAboutMeetings = qLower.contains("встреч") || qLower.contains("созвон") || qLower.contains("договор")
                || qLower.contains("обсужд") || qLower.contains("говорил") || qLower.contains("кто");
        boolean asksAboutWhen = qLower.contains("когда") || qLower.contains("число") || qLower.contains("дата") || qLower.contains("во сколько");

        String[] qTokens = qLower.replaceAll("[^а-яa-z0-9\\s]", "").split("\\s+");
        List<String> stems = new ArrayList<>();
        for (String w : qTokens) {
            if (w.length() >= 4) {
                stems.add(w.substring(0, Math.min(w.length() - 1, 6)));
            } else if (w.length() > 1 && !isStopWord(w)) {
                stems.add(w);
            }
        }

        List<ScoredItem> scored = new ArrayList<>();
        for (EntryItem item : items) {
            String textLower = item.text.toLowerCase();
            int score = 0;
            int matchedStems = 0;

            for (String s : stems) {
                if (textLower.contains(s)) {
                    score += 3;
                    matchedStems++;
                }
            }

            if (item.isImportant) score += 2;

            if (asksAboutTasks && (textLower.contains("задач") || textLower.contains("сделать") || textLower.contains("купить") || textLower.contains("нужно"))) {
                score += 2;
            }
            if (asksAboutMeetings && (textLower.contains("встреч") || textLower.contains("созвон") || textLower.contains("договор"))) {
                score += 2;
            }

            if (matchedStems > 0 || (stems.isEmpty() && item.isImportant)) {
                scored.add(new ScoredItem(item, score));
            }
        }

        if (scored.isEmpty()) {
            return "Я просмотрел весь архив дневника, но точных совпадений по вашему вопросу не нашёл.\n\nПопробуйте уточнить ключевые слова или назвать ориентировочную дату.";
        }

        scored.sort((a, b) -> Integer.compare(b.score, a.score));

        StringBuilder response = new StringBuilder();

        if (asksAboutTasks) {
            response.append("Судя по вашим записям, зафиксированы следующие задачи:\n\n");
            int limit = Math.min(3, scored.size());
            for (int i = 0; i < limit; i++) {
                EntryItem it = scored.get(i).item;
                response.append("• ").append(it.text);
                if (it.time != null && !it.time.isEmpty()) {
                    response.append(" (").append(it.time).append(")");
                }
                response.append("\n");
            }
        } else if (asksAboutMeetings) {
            response.append("По поводу встреч и обсуждений удалось найти следующее:\n\n");
            int limit = Math.min(3, scored.size());
            for (int i = 0; i < limit; i++) {
                EntryItem it = scored.get(i).item;
                if (it.time != null && !it.time.isEmpty()) {
                    response.append("🗓 Запись от ").append(it.time).append(":\n");
                }
                response.append("«").append(it.text).append("»\n\n");
            }
        } else if (asksAboutWhen) {
            EntryItem top = scored.get(0).item;
            response.append("Это упоминается в записи от ").append(top.time != null ? top.time : "архива").append(":\n\n");
            response.append("«").append(top.text).append("»");
        } else {
            EntryItem top = scored.get(0).item;
            response.append("По вашим записям: ");
            response.append(top.text).append("\n\n");

            if (scored.size() > 1) {
                response.append("Также в этот контекст входит:\n");
                int limit = Math.min(3, scored.size());
                for (int i = 1; i < limit; i++) {
                    EntryItem it = scored.get(i).item;
                    response.append("• ").append(it.text);
                    if (it.time != null && !it.time.isEmpty()) {
                        response.append(" (").append(it.time).append(")");
                    }
                    response.append("\n");
                }
            }
        }

        return response.toString().trim();
    }

    private static String extractTime(String created) {
        if (created == null) return "--:--";
        if (created.length() >= 16) {
            return created.substring(11, 16);
        }
        return created;
    }

    private static boolean isStopWord(String w) {
        return w.equals("что") || w.equals("как") || w.equals("где") || w.equals("кто")
                || w.equals("или") || w.equals("для") || w.equals("про") || w.equals("это")
                || w.equals("был") || w.equals("было") || w.equals("мне");
    }

    private static List<EntryItem> parseEntries(String context) {
        List<EntryItem> list = new ArrayList<>();
        String[] splits = context.split("\\n\\n+");
        for (String s : splits) {
            String trimmed = s.trim();
            if (trimmed.isEmpty()) continue;

            String time = null;
            boolean important = trimmed.contains("★") || trimmed.toLowerCase().contains("важно");

            if (trimmed.startsWith("[") && trimmed.contains("]")) {
                int endIdx = trimmed.indexOf("]");
                time = trimmed.substring(1, endIdx).trim();
                trimmed = trimmed.substring(endIdx + 1).trim();
            } else if (trimmed.matches("^\\d{4}-\\d{2}-\\d{2}.*")) {
                int colonIdx = trimmed.indexOf(":");
                if (colonIdx > 10 && colonIdx < 22) {
                    time = trimmed.substring(0, colonIdx).trim();
                    trimmed = trimmed.substring(colonIdx + 1).trim();
                }
            }

            trimmed = trimmed.replaceFirst("^[•★\\-\\*\\s]+", "").trim();
            if (trimmed.startsWith("ВАЖНО:")) {
                trimmed = trimmed.substring(6).trim();
            }

            if (!trimmed.isEmpty()) {
                list.add(new EntryItem(time, trimmed, important));
            }
        }
        return list;
    }

    private static class EntryItem {
        String time;
        String text;
        boolean isImportant;
        EntryItem(String time, String text, boolean isImportant) {
            this.time = time;
            this.text = text;
            this.isImportant = isImportant;
        }
    }

    private static class ScoredItem {
        EntryItem item;
        int score;
        ScoredItem(EntryItem item, int score) {
            this.item = item;
            this.score = score;
        }
    }
}
