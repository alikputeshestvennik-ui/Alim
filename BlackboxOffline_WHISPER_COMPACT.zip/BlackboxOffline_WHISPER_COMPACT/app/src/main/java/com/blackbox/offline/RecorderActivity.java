package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;

public class RecorderActivity extends Activity {
    private Button toggleBtn;
    private boolean isActive = false;
    private TextView statusTitle;
    private TextView statusDesc;
    private LinearLayout statusCard;
    private ImageView waveformView;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            isActive = i.getBooleanExtra("active", isActive);
            updateStatusUi();
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        RetentionManager.clean(this);

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE));
        }

        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 20);
        // Comfortable top padding: 48dp on modern devices to sit nicely below punch-hole camera/cutout
        int padTop = UI.dp(this, 48);
        int padBottom = UI.dp(this, 28);
        root.setPadding(padH, padTop, padH, padBottom);

        // Header: Pure clean design
        root.addView(UI.createHeader(this, "BLACKBOX", "Автономный аудио-дневник", false));

        // Hero Status Card
        statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        int cardPad = UI.dp(this, 22);
        statusCard.setPadding(cardPad, cardPad, cardPad, cardPad);

        statusTitle = new TextView(this);
        statusTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        statusTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        statusCard.addView(statusTitle);

        statusDesc = new TextView(this);
        statusDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        statusDesc.setTextColor(UI.COLOR_TEXT_MUTED);
        statusDesc.setPadding(0, UI.dp(this, 6), 0, UI.dp(this, 14));
        statusCard.addView(statusDesc);

        // Stylish Vector Waveform Graphic
        waveformView = new ImageView(this);
        int waveRes = getResources().getIdentifier("waveform_banner", "drawable", getPackageName());
        if (waveRes != 0) waveformView.setImageResource(waveRes);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, UI.dp(this, 32));
        wlp.bottomMargin = UI.dp(this, 16);
        statusCard.addView(waveformView, wlp);

        toggleBtn = new Button(this);
        toggleBtn.setAllCaps(false);
        toggleBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        toggleBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        int btnPadH = UI.dp(this, 20);
        int btnPadV = UI.dp(this, 14);
        toggleBtn.setPadding(btnPadH, btnPadV, btnPadH, btnPadV);
        toggleBtn.setOnClickListener(v -> {
            if (isActive) {
                startService(new Intent(this, RecordingService.class).setAction(RecordingService.STOP));
            } else if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startRecordingService();
            } else {
                requestPermissions(new String[]{
                        android.Manifest.permission.RECORD_AUDIO,
                        Build.VERSION.SDK_INT >= 33 ? android.Manifest.permission.POST_NOTIFICATIONS : android.Manifest.permission.RECORD_AUDIO
                }, 42);
            }
        });
        statusCard.addView(toggleBtn);

        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(-1, -2);
        scLp.bottomMargin = UI.dp(this, 26);
        root.addView(statusCard, scLp);

        // Section Title: Quick Navigation
        TextView navTitle = new TextView(this);
        navTitle.setText("РАЗДЕЛЫ ДНЕВНИКА");
        navTitle.setTextColor(UI.COLOR_TEXT_SUBTLE);
        navTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        navTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        navTitle.setPadding(UI.dp(this, 4), 0, 0, UI.dp(this, 12));
        root.addView(navTitle);

        // Navigation Card Buttons with Vector Graphics
        addNavItem(root, "ic_nav_history", "История и записи", "Аудиозаписи, расшифровки и воспроизведение", HistoryActivity.class);
        addNavItem(root, "ic_nav_summary", "Итоги дня", "Интеллектуальная сводка задач и встреч", SummaryActivity.class);
        addNavItem(root, "ic_nav_search", "Спросить дневник", "Поиск и смысловой анализ Qwen AI", AskDiaryActivity.class);
        addNavItem(root, "ic_nav_models", "AI-модели", "Статус Whisper STT и Qwen LLM", ModelsActivity.class);

        scroll.addView(root);
        setContentView(scroll);

        updateStatusUi();
    }

    private void addNavItem(LinearLayout parent, String iconName, String title, String sub, Class<?> target) {
        View v = UI.navCardButton(this, iconName, title, sub, view -> startActivity(new Intent(this, target)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = UI.dp(this, 10);
        parent.addView(v, lp);
    }

    private void updateStatusUi() {
        if (statusCard == null || toggleBtn == null) return;

        if (isActive) {
            statusCard.setBackground(UI.shape(0xFF221111, 0xFF992222, 16, this));
            statusTitle.setText("Фоновая запись активна");
            statusTitle.setTextColor(UI.COLOR_RED);
            statusDesc.setText("Слушает речь в фоне. Скажите «Блэкбокс, стоп» для выключения.");
            toggleBtn.setText("Остановить фоновую запись");
            toggleBtn.setTextColor(Color.WHITE);
            toggleBtn.setBackground(UI.buttonRipple(UI.gradient(0xFFB91C1C, 0xFFEF4444, 14, this), 0x55FFFFFF));
        } else {
            statusCard.setBackground(UI.shape(UI.COLOR_SURFACE, UI.COLOR_BORDER, 16, this));
            statusTitle.setText("Фоновая запись выключена");
            statusTitle.setTextColor(UI.COLOR_TEXT_PRIMARY);
            statusDesc.setText("Нажмите кнопку, чтобы запустить автономное распознавание речи.");
            toggleBtn.setText("Включить фоновую запись");
            toggleBtn.setTextColor(Color.WHITE);
            toggleBtn.setBackground(UI.buttonRipple(UI.gradient(UI.COLOR_ORANGE, UI.COLOR_ORANGE_LIGHT, 14, this), 0x55FFFFFF));
        }
    }

    private void startRecordingService() {
        Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.START);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        isActive = true;
        updateStatusUi();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startRecordingService();
        } else {
            Toast.makeText(this, "Необходим доступ к микрофону для фоновой записи", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(stateReceiver);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
