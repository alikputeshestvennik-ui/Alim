package com.blackbox.offline;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;

public class RecorderActivity extends Activity {
    Button toggle;
    boolean on;
    BroadcastReceiver r = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            on = i.getBooleanExtra("active", on);
            draw();
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        RetentionManager.clean(this);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, new IntentFilter(RecordingService.STATE), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(r, new IntentFilter(RecordingService.STATE));
        }
        draw();
    }

    void draw() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(36, 45, 36, 36);
        l.setBackgroundColor(0xff0b0c0d);
        add(l, "Blackbox", 28);
        add(l, on ? "● Фоновая запись активна" : "● Фоновая запись выключена", 18);
        toggle = new Button(this);
        toggle.setText(on ? "■ Остановить" : "● Включить фоновую запись");
        l.addView(toggle);
        toggle.setOnClickListener(v -> {
            if (on) {
                startService(new Intent(this, RecordingService.class).setAction(RecordingService.STOP));
            } else if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                go();
            } else {
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, 4);
            }
        });
        add(l, "После 2 секунд тишины или 10 минут записи фрагмент автоматически попадает в очередь Whisper base. Обычное аудио хранится 7 дней. Слова «Блэкбокс, важно» и «Запомни это» помечают фрагмент как важный.", 14);
        button(l, "История и важное", HistoryActivity.class);
        button(l, "Итоги дня", SummaryActivity.class);
        button(l, "Спросить дневник", AskDiaryActivity.class);
        button(l, "AI-модели", ModelsActivity.class);
        setContentView(new ScrollView(this) {{
            addView(l);
        }});
    }

    void go() {
        Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.START);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        on = true;
        draw();
    }

    @Override
    public void onRequestPermissionsResult(int a, String[] b, int[] g) {
        super.onRequestPermissionsResult(a, b, g);
        if (g.length > 0 && g[0] == 0) go();
    }

    void button(LinearLayout l, String s, Class c) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        l.addView(b);
        b.setOnClickListener(v -> startActivity(new Intent(this, c)));
    }

    void add(LinearLayout l, String x, int z) {
        TextView v = new TextView(this);
        v.setText(x);
        v.setTextColor(Color.WHITE);
        v.setTextSize(z);
        v.setPadding(0, 15, 0, 15);
        l.addView(v);
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(r);
        } catch (Exception ignored) {}
        super.onDestroy();
    }
}
