package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;

public class RecorderActivity extends Activity {
    private Button toggleBtn;
    private boolean isActive = false;
    private TextView statusTitle;
    private TextView statusDesc;
    private LinearLayout statusCard;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            isActive = i.getBooleanExtra("active", isActive);
            updateStatusUi();
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        RetentionManager.clean(this);

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE));
        }

        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 20);
        int padV = UI.dp(this, 24);
        root.setPadding(padH, padV, padH, padV);

        // Header
        root.addView(UI.createHeader(this, "BLACKBOX", "Автономный аудио-дневник", false));

        // Hero Status Card
        statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        int cardPad = UI.dp(this, 20);
        statusCard.setPadding(cardPad, cardPad, cardPad, cardPad);

        LinearLayout topIndicator = new LinearLayout(this);
        topIndicator.setOrientation(LinearLayout.HORIZONTAL);
        topIndicator.setGravity(Gravity.CENTER_VERTICAL);

        statusTitle = new TextView(this);
        statusTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        statusTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        topIndicator.addView(statusTitle);
        statusCard.addView(topIndicator);

        statusDesc = new TextView(this);
        statusDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        statusDesc.setTextColor(UI.COLOR_TEXT_MUTED);
        statusDesc.setPadding(0, UI.dp(this, 6), 0, UI.dp(this, 18));
        statusCard.addView(statusDesc);

        toggleBtn = new Button(this);
        toggleBtn.setAllCaps(false);
        toggleBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        toggleBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        int btnPadH = UI.dp(this, 20);
        int btnPadV = UI.dp(this, 14);
        toggleBtn.setPadding(btnPadH, btnPadV, btnPadH, btnPadV);
        toggleBtn.setOnClickListener(v -> {
            if (isActive) {
                startService(new Intent(this, RecordingService.class).setAction(RecordingService.STOP));
            } else if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startRecordingService();
            } else {
                requestPermissions(new String[]{
                        android.Manifest.permission.RECORD_AUDIO,
                        Build.VERSION.SDK_INT >= 33 ? android.Manifest.permission.POST_NOTIFICATIONS : android.Manifest.permission.RECORD_AUDIO
                }, 42);
            }
        });
        statusCard.addView(toggleBtn);

        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(-1, -2);
        scLp.bottomMargin = UI.dp(this, 24);
        root.addView(statusCard, scLp);

        // Section Title: Quick Navigation
        TextView navTitle = new TextView(this);
        navTitle.setText("РАЗДЕЛЫ ДНЕВНИКА");
        navTitle.setTextColor(UI.COLOR_TEXT_SUBTLE);
        navTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        navTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        navTitle.setPadding(UI.dp(this, 4), 0, 0, UI.dp(this, 10));
        root.addView(navTitle);

        // Navigation Card Buttons
        addNavItem(root, "📜", "История и записи", "Все сохранённые аудио и текст расшифровок", HistoryActivity.class);
        addNavItem(root, "✨", "Итоги дня", "Локальная сводка событий за выбранную дату", SummaryActivity.class);
        addNavItem(root, "🔍", "Поиск по дневнику", "Поиск ключевых фраз и важных моментов", AskDiaryActivity.class);
        addNavItem(root, "⚙", "AI-модели", "Статус Whisper GGML и Qwen GGUF", ModelsActivity.class);

        // Bottom Info Card
        LinearLayout info = UI.createCard(this);
        info.setBackground(UI.shape(0xFF0F1216, UI.COLOR_BORDER, 14, this));

        TextView infoTitle = new TextView(this);
        infoTitle.setText("🛡 Приватность и алгоритм");
        infoTitle.setTextColor(UI.COLOR_ORANGE_LIGHT);
        infoTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        infoTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        info.addView(infoTitle);

        TextView infoText = new TextView(this);
        infoText.setText("Фрагмент создаётся после 2 сек тишины или каждые 10 мин. Фразы «Блэкбокс, важно» и «Запомни это» маркируют запись звёздочкой (★) и защищают от 7-дневной автоочистки.");
        infoText.setTextColor(UI.COLOR_TEXT_MUTED);
        infoText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        infoText.setPadding(0, UI.dp(this, 6), 0, 0);
        info.addView(infoText);

        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1, -2);
        infoLp.topMargin = UI.dp(this, 16);
        root.addView(info, infoLp);

        scroll.addView(root);
        setContentView(scroll);

        updateStatusUi();
    }

    private void addNavItem(LinearLayout parent, String icon, String title, String sub, Class<?> target) {
        View v = UI.navCardButton(this, icon, title, sub, view -> startActivity(new Intent(this, target)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = UI.dp(this, 10);
        parent.addView(v, lp);
    }

    private void updateStatusUi() {
        if (statusCard == null || toggleBtn == null) return;

        if (isActive) {
            statusCard.setBackground(UI.shape(0xFF221111, 0xFF992222, 16, this));
            statusTitle.setText("● ФОНОВАЯ ЗАПИСЬ АКТИВНА");
            statusTitle.setTextColor(UI.COLOR_RED);
            statusDesc.setText("Микрофон слушает речь в фоне. При тишине аудио отправится в очередь Whisper.");
            toggleBtn.setText("■ Остановить фоновую запись");
            toggleBtn.setTextColor(Color.WHITE);
            toggleBtn.setBackground(UI.buttonRipple(UI.gradient(0xFFB91C1C, 0xFFEF4444, 14, this), 0x55FFFFFF));
        } else {
            statusCard.setBackground(UI.shape(UI.COLOR_SURFACE, UI.COLOR_BORDER, 16, this));
            statusTitle.setText("○ Фоновая запись выключена");
            statusTitle.setTextColor(UI.COLOR_TEXT_PRIMARY);
            statusDesc.setText("Нажмите кнопку, чтобы запустить непрерывное локальное сохранение аудио.");
            toggleBtn.setText("● Включить фоновую запись");
            toggleBtn.setTextColor(Color.WHITE);
            toggleBtn.setBackground(UI.buttonRipple(UI.gradient(UI.COLOR_ORANGE, UI.COLOR_ORANGE_LIGHT, 14, this), 0x55FFFFFF));
        }
    }

    private void startRecordingService() {
        Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.START);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        isActive = true;
        updateStatusUi();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startRecordingService();
        } else {
            Toast.makeText(this, "Для работы фоновой записи необходим доступ к микрофону", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(stateReceiver);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
