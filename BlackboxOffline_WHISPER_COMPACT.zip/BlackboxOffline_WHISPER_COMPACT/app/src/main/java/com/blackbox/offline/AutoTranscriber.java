package com.blackbox.offline;

import android.content.Context;
import android.content.Intent;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Sequential local Whisper processing queue.
 * Performs real-time classification into categories: Задачи, Встречи, Идеи, Заметки.
 */
public final class AutoTranscriber {
    private static final ExecutorService queue = Executors.newSingleThreadExecutor();

    private AutoTranscriber() {}

    public static void enqueue(Context c, Entry e) {
        Context app = c.getApplicationContext();
        queue.execute(() -> {
            try {
                e.status = "Расшифровка…";
                new EntryStore(app).replace(e);

                String text = new LocalAiEngine(app).transcribe(e.path);
                e.transcript = text;
                e.status = "Готово";

                String lower = text.toLowerCase();
                // 1. Detection of important marker phrases
                e.important = lower.contains("блэкбокс важно")
                        || lower.contains("blackbox важно")
                        || lower.contains("запомни это")
                        || lower.contains("очень важно")
                        || lower.contains("важная мысль");

                if (e.important) {
                    e.summary = "ВАЖНО";
                }

                // 2. Smart Categorization
                e.category = detectCategory(lower);

                new EntryStore(app).replace(e);
                app.sendBroadcast(new Intent(RecordingService.ENTRIES).setPackage(app.getPackageName()));
            } catch (Exception x) {
                e.status = "Ошибка: " + (x.getMessage() == null ? "расшифровка" : x.getMessage());
                new EntryStore(app).replace(e);
            }
        });
    }

    public static String detectCategory(String lower) {
        if (lower.contains("задач") || lower.contains("сделать") || lower.contains("купить")
                || lower.contains("нужно") || lower.contains("надо") || lower.contains("список")
                || lower.contains("напомни") || lower.contains("чеклист")) {
            return "Задачи";
        }
        if (lower.contains("встреч") || lower.contains("созвон") || lower.contains("звонок")
                || lower.contains("договорил") || lower.contains("встрет") || lower.contains("планёрк")
                || lower.contains("митинг") || lower.contains("в 1") || lower.contains("в 2") || lower.contains("часов")) {
            return "Встречи";
        }
        if (lower.contains("идея") || lower.contains("придумал") || lower.contains("мысль")
                || lower.contains("проект") || lower.contains("концепт") || lower.contains("гипотез")) {
            return "Идеи";
        }
        return "Заметки";
    }
}
