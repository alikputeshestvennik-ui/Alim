package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class HistoryActivity extends Activity {
    LinearLayout list;
    BroadcastReceiver r = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            draw();
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(r, new IntentFilter(RecordingService.ENTRIES), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(r, new IntentFilter(RecordingService.ENTRIES));
        }
        draw();
    }

    void draw() {
        ScrollView s = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(28, 35, 28, 28);
        list.setBackgroundColor(0xff0b0c0d);
        text("История", 28, Color.WHITE);
        ArrayList<Entry> a = new EntryStore(this).all();
        if (a.isEmpty()) {
            text("Записей пока нет.", 16, 0xffb7b1a8);
        }
        for (Entry e : a) {
            card(e);
        }
        s.addView(list);
        setContentView(s);
    }

    void card(Entry e) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(18, 14, 18, 14);
        c.setBackgroundColor(e.important ? 0xff50321d : 0xff242629);

        text(c, (e.important ? "★ ВАЖНО · " : "") + e.created + " · " + e.duration + " сек", 16, Color.WHITE);
        text(c, e.status, 13, 0xffffa05c);

        String p = e.transcript.isEmpty() ? "Текст появится автоматически после расшифровки." : e.transcript;
        text(c, p, 16, 0xffe8e3dd);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button show = new Button(this);
        show.setText("Полный текст");
        show.setAllCaps(false);
        buttons.addView(show);
        show.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(e.important ? "Важная запись" : "Расшифровка")
                .setMessage(e.transcript.isEmpty() ? e.status : e.transcript)
                .setPositiveButton("Закрыть", null)
                .show());

        Button retranscribe = new Button(this);
        retranscribe.setText("Расшифровать");
        retranscribe.setAllCaps(false);
        buttons.addView(retranscribe);
        retranscribe.setOnClickListener(v -> {
            AutoTranscriber.enqueue(this, e);
            Toast.makeText(this, "Добавлено в очередь Whisper", Toast.LENGTH_SHORT).show();
            draw();
        });

        c.addView(buttons);
        list.addView(c, new LinearLayout.LayoutParams(-1, -2) {{
            setMargins(0, 0, 0, 14);
        }});
    }

    void text(String x, int z, int c) {
        text(list, x, z, c);
    }

    void text(LinearLayout l, String x, int z, int c) {
        TextView v = new TextView(this);
        v.setText(x);
        v.setTextSize(z);
        v.setTextColor(c);
        v.setPadding(0, 6, 0, 6);
        l.addView(v);
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(r);
        } catch (Exception ignored) {}
        super.onDestroy();
    }
}
