package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;

public class HistoryActivity extends Activity {
    private LinearLayout listContainer;
    private final BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            drawList();
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, new IntentFilter(RecordingService.ENTRIES), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(updateReceiver, new IntentFilter(RecordingService.ENTRIES));
        }
        drawList();
    }

    private void drawList() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        listContainer.setPadding(padH, padV, padH, padV);

        ArrayList<Entry> entries = new EntryStore(this).all();

        // Header with counter
        String sub = entries.isEmpty() ? "Записей пока нет" : "Всего сохранённых фрагментов: " + entries.size();
        listContainer.addView(UI.createHeader(this, "История событий", sub, true));

        if (entries.isEmpty()) {
            LinearLayout emptyCard = UI.createCard(this);
            emptyCard.setGravity(Gravity.CENTER);
            int emptyPad = UI.dp(this, 36);
            emptyCard.setPadding(emptyPad, emptyPad, emptyPad, emptyPad);

            TextView icon = new TextView(this);
            icon.setText("🎙");
            icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36);
            emptyCard.addView(icon);

            TextView emptyTitle = new TextView(this);
            emptyTitle.setText("Пока нет записей");
            emptyTitle.setTextColor(UI.COLOR_TEXT_TITLE);
            emptyTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
            emptyTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            emptyTitle.setPadding(0, UI.dp(this, 10), 0, UI.dp(this, 4));
            emptyCard.addView(emptyTitle);

            TextView emptyDesc = new TextView(this);
            emptyDesc.setText("Включите фоновую запись на главном экране. Фрагменты появятся здесь после завершения речи.");
            emptyDesc.setTextColor(UI.COLOR_TEXT_MUTED);
            emptyDesc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            emptyDesc.setGravity(Gravity.CENTER);
            emptyCard.addView(emptyDesc);

            listContainer.addView(emptyCard);
        } else {
            for (Entry e : entries) {
                renderEntryCard(e);
            }
        }

        scroll.addView(listContainer);
        setContentView(scroll);
    }

    private void renderEntryCard(Entry e) {
        LinearLayout card = e.important ? UI.createImportantCard(this) : UI.createCard(this);

        // Top metadata row
        LinearLayout metaRow = new LinearLayout(this);
        metaRow.setOrientation(LinearLayout.HORIZONTAL);
        metaRow.setGravity(Gravity.CENTER_VERTICAL);

        if (e.important) {
            TextView importantBadge = UI.badge(this, "★ ВАЖНО", UI.COLOR_ORANGE_LIGHT, 0x33F47721);
            metaRow.addView(importantBadge);
        }

        TextView timeBadge = UI.badge(this, e.created, UI.COLOR_TEXT_PRIMARY, 0xFF1E232B);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        if (e.important) tlp.leftMargin = UI.dp(this, 8);
        metaRow.addView(timeBadge, tlp);

        TextView durBadge = UI.badge(this, e.duration + " сек", UI.COLOR_TEXT_MUTED, 0xFF191D24);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-2, -2);
        dlp.leftMargin = UI.dp(this, 6);
        metaRow.addView(durBadge, dlp);

        // Spacer to push status to the right
        View spacer = new View(this);
        LinearLayout.LayoutParams splp = new LinearLayout.LayoutParams(0, 1, 1.0f);
        metaRow.addView(spacer, splp);

        // Status pill
        boolean isDone = "Готово".equals(e.status);
        boolean isTranscribing = e.status != null && e.status.contains("Расшифровка");
        int statusColor = isDone ? UI.COLOR_GREEN : (isTranscribing ? UI.COLOR_ORANGE : UI.COLOR_TEXT_MUTED);
        int statusBg = isDone ? UI.COLOR_GREEN_BG : (isTranscribing ? UI.COLOR_ORANGE_DIM : 0xFF1C2027);
        TextView statusPill = UI.badge(this, e.status, statusColor, statusBg);
        metaRow.addView(statusPill);

        card.addView(metaRow);

        // Transcript body
        TextView body = new TextView(this);
        String text = (e.transcript == null || e.transcript.trim().isEmpty())
                ? "Текст появится автоматически после обработки в Whisper..."
                : e.transcript;
        body.setText(text);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        body.setTextColor(e.transcript == null || e.transcript.isEmpty() ? UI.COLOR_TEXT_MUTED : UI.COLOR_TEXT_PRIMARY);
        body.setLineSpacing(UI.dp(this, 4), 1.0f);
        body.setPadding(0, UI.dp(this, 12), 0, UI.dp(this, 14));
        card.addView(body);

        // Buttons row
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button showBtn = UI.secondaryButton(this, "Полный текст");
        showBtn.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(e.important ? "★ Важная запись" : "Расшифровка (" + e.created + ")")
                .setMessage(e.transcript == null || e.transcript.isEmpty() ? e.status : e.transcript)
                .setPositiveButton("Копировать", (dialog, which) -> UI.copyToClipboard(this, "Запись", e.transcript))
                .setNegativeButton("Закрыть", null)
                .show());
        actions.addView(showBtn);

        Button retryBtn = UI.secondaryButton(this, "Расшифровать");
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-2, -2);
        rlp.leftMargin = UI.dp(this, 8);
        retryBtn.setOnClickListener(v -> {
            AutoTranscriber.enqueue(this, e);
            Toast.makeText(this, "Фрагмент добавлен в очередь Whisper", Toast.LENGTH_SHORT).show();
            drawList();
        });
        actions.addView(retryBtn, rlp);

        card.addView(actions);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = UI.dp(this, 12);
        listContainer.addView(card, cardLp);
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(updateReceiver);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
