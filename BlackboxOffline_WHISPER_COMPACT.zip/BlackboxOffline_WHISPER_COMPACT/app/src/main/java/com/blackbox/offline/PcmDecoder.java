package com.blackbox.offline;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;

/** Decodes audio (WAV, AAC, M4A) to mono 16 kHz float PCM for whisper.cpp. */
final class PcmDecoder {
    private PcmDecoder() {}

    static float[] decode16kMono(String path) throws Exception {
        File file = new File(path);
        if (!file.exists() || file.length() == 0) {
            throw new IllegalArgumentException("Файл аудио пуст или не существует: " + path);
        }

        // Try reading directly as 16-bit PCM WAV first
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] header = new byte[12];
            int r = fis.read(header);
            if (r == 12 && new String(header, 0, 4).equals("RIFF") && new String(header, 8, 4).equals("WAVE")) {
                int sampleRate = 16000;
                int channels = 1;
                byte[] chunk = new byte[8];
                while (fis.read(chunk) == 8) {
                    String id = new String(chunk, 0, 4);
                    int size = (chunk[4] & 0xFF) | ((chunk[5] & 0xFF) << 8) | ((chunk[6] & 0xFF) << 16) | ((chunk[7] & 0xFF) << 24);
                    if ("fmt ".equals(id)) {
                        byte[] fmt = new byte[size];
                        fis.read(fmt);
                        channels = (fmt[2] & 0xFF) | ((fmt[3] & 0xFF) << 8);
                        sampleRate = (fmt[4] & 0xFF) | ((fmt[5] & 0xFF) << 8) | ((fmt[6] & 0xFF) << 16) | ((fmt[7] & 0xFF) << 24);
                    } else if ("data".equals(id)) {
                        byte[] data = new byte[size];
                        int total = 0;
                        while (total < size) {
                            int n = fis.read(data, total, size - total);
                            if (n <= 0) break;
                            total += n;
                        }
                        ByteBuffer bb = ByteBuffer.wrap(data, 0, total).order(ByteOrder.LITTLE_ENDIAN);
                        int samplesPerChannel = total / (2 * channels);
                        ArrayList<Float> mono = new ArrayList<>(samplesPerChannel);
                        for (int i = 0; i < samplesPerChannel; i++) {
                            float sum = 0;
                            for (int c = 0; c < channels; c++) {
                                sum += bb.getShort() / 32768.0f;
                            }
                            mono.add(sum / channels);
                        }
                        if (sampleRate == 16000) {
                            float[] out = new float[mono.size()];
                            for (int i = 0; i < mono.size(); i++) out[i] = mono.get(i);
                            return out;
                        } else {
                            int outCount = (int) ((long) mono.size() * 16000 / sampleRate);
                            float[] out = new float[outCount];
                            for (int i = 0; i < outCount; i++) {
                                double p = (double) i * sampleRate / 16000;
                                int a = (int) p, b = Math.min(a + 1, mono.size() - 1);
                                double k = p - a;
                                out[i] = (float) (mono.get(a) * (1 - k) + mono.get(b) * k);
                            }
                            return out;
                        }
                    } else {
                        fis.skip(size);
                    }
                }
            }
        } catch (Exception ignored) {
            // Fallback to MediaExtractor / MediaCodec
        }

        // Fallback for compressed containers (AAC, M4A, etc.)
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(path);
        int track = -1;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            MediaFormat f = ex.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) {
                track = i;
                break;
            }
        }
        if (track < 0) {
            ex.release();
            throw new IllegalArgumentException("В записи нет аудиодорожки");
        }
        ex.selectTrack(track);
        MediaFormat in = ex.getTrackFormat(track);
        String mime = in.getString(MediaFormat.KEY_MIME);
        MediaCodec codec = MediaCodec.createDecoderByType(mime);
        codec.configure(in, null, null, 0);
        codec.start();

        int srcRate = in.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? in.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
        int srcChannels = in.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? in.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
        ArrayList<Float> mono = new ArrayList<>();
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false, outputDone = false;

        while (!outputDone) {
            if (!inputDone) {
                int idx = codec.dequeueInputBuffer(10000);
                if (idx >= 0) {
                    ByteBuffer b = codec.getInputBuffer(idx);
                    int n = ex.readSampleData(b, 0);
                    if (n < 0) {
                        codec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                    } else {
                        codec.queueInputBuffer(idx, 0, n, ex.getSampleTime(), 0);
                        ex.advance();
                    }
                }
            }
            int out = codec.dequeueOutputBuffer(info, 10000);
            if (out >= 0) {
                ByteBuffer b = codec.getOutputBuffer(out);
                if (b != null && info.size > 0) {
                    b.position(info.offset);
                    b.limit(info.offset + info.size);
                    b.order(ByteOrder.LITTLE_ENDIAN);
                    while (b.remaining() >= 2) {
                        float total = 0;
                        int got = 0;
                        for (int c = 0; c < srcChannels && b.remaining() >= 2; c++) {
                            total += b.getShort() / 32768f;
                            got++;
                        }
                        if (got > 0) mono.add(total / got);
                    }
                }
                codec.releaseOutputBuffer(out, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
            }
        }
        codec.stop();
        codec.release();
        ex.release();
        if (mono.isEmpty()) throw new IllegalStateException("Не удалось декодировать аудио");

        int outCount = (int) ((long) mono.size() * 16000 / srcRate);
        float[] out = new float[outCount];
        for (int i = 0; i < outCount; i++) {
            double p = (double) i * srcRate / 16000;
            int a = (int) p, b = Math.min(a + 1, mono.size() - 1);
            double k = p - a;
            out[i] = (float) (mono.get(a) * (1 - k) + mono.get(b) * k);
        }
        return out;
    }
}
