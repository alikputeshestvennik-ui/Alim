package com.blackbox.offline;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Premium Obsidian & Blackbox-Orange UI design system.
 * Zero external library dependencies (runs purely on Android SDK 26+).
 */
public final class UI {
    // Luxury dark obsidian palette
    public static final int COLOR_BG = 0xFF0A0B0E;
    public static final int COLOR_SURFACE = 0xFF13161B;
    public static final int COLOR_SURFACE_ELEVATED = 0xFF191D24;
    public static final int COLOR_BORDER = 0xFF222832;

    // Vibrant signature Blackbox orange
    public static final int COLOR_ORANGE = 0xFFF47721;
    public static final int COLOR_ORANGE_LIGHT = 0xFFFF8D3A;
    public static final int COLOR_ORANGE_DARK = 0xFFC95408;
    public static final int COLOR_ORANGE_DIM = 0x22F47721;
    public static final int COLOR_ORANGE_BORDER = 0xFF66300C;

    // Important card glowing amber
    public static final int COLOR_IMPORTANT_BG = 0xFF1D140C;
    public static final int COLOR_IMPORTANT_BORDER = 0xFFA85012;

    // Text colors
    public static final int COLOR_TEXT_TITLE = 0xFFFFFFFF;
    public static final int COLOR_TEXT_PRIMARY = 0xFFEDEDF0;
    public static final int COLOR_TEXT_MUTED = 0xFF8E95A2;
    public static final int COLOR_TEXT_SUBTLE = 0xFF585F6B;
    public static final int COLOR_TEXT_ORANGE = 0xFFFFA05C;

    // Status colors
    public static final int COLOR_GREEN = 0xFF22C55E;
    public static final int COLOR_GREEN_BG = 0x2222C55E;
    public static final int COLOR_RED = 0xFFEF4444;
    public static final int COLOR_RED_BG = 0x28EF4444;

    private UI() {}

    public static int dp(Context c, int val) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, c.getResources().getDisplayMetrics());
    }

    public static GradientDrawable shape(int bgColor, int borderColor, int radiusDp, Context c) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(c, radiusDp));
        if (borderColor != 0) {
            gd.setStroke(dp(c, 1), borderColor);
        }
        return gd;
    }

    public static GradientDrawable gradient(int startColor, int endColor, int radiusDp, Context c) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{startColor, endColor});
        gd.setCornerRadius(dp(c, radiusDp));
        return gd;
    }

    public static RippleDrawable buttonRipple(GradientDrawable content, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
    }

    public static LinearLayout createHeader(Activity a, String title, String subtitle, boolean showBack) {
        Context c = a;
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setPadding(0, 0, 0, dp(c, 16));

        // Top tag row
        LinearLayout tagRow = new LinearLayout(c);
        tagRow.setOrientation(LinearLayout.HORIZONTAL);
        tagRow.setGravity(Gravity.CENTER_VERTICAL);

        if (showBack) {
            TextView back = new TextView(c);
            back.setText("‹ Назад");
            back.setTextColor(COLOR_ORANGE);
            back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            back.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            back.setPadding(0, dp(c, 4), dp(c, 16), dp(c, 4));
            back.setOnClickListener(v -> a.finish());
            tagRow.addView(back);
        }

        TextView offlineBadge = badge(c, "● 100% ОФЛАЙН", COLOR_GREEN, COLOR_GREEN_BG);
        tagRow.addView(offlineBadge);

        TextView whisperBadge = badge(c, "WHISPER AI", COLOR_ORANGE, COLOR_ORANGE_DIM);
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-2, -2);
        wlp.leftMargin = dp(c, 8);
        tagRow.addView(whisperBadge, wlp);

        bar.addView(tagRow);

        // Title and Logo row
        LinearLayout titleRow = new LinearLayout(c);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, dp(c, 10), 0, 0);

        ImageView mark = new ImageView(c);
        try {
            int resId = c.getResources().getIdentifier("blackbox_mark", "drawable", c.getPackageName()); if (resId != 0) mark.setImageResource(resId);
        } catch (Throwable ignored) {}
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(c, 36), dp(c, 36));
        mlp.rightMargin = dp(c, 12);
        titleRow.addView(mark, mlp);

        LinearLayout textCol = new LinearLayout(c);
        textCol.setOrientation(LinearLayout.VERTICAL);

        TextView tvTitle = new TextView(c);
        tvTitle.setText(title);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        tvTitle.setTextColor(COLOR_TEXT_TITLE);
        tvTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        textCol.addView(tvTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvSub = new TextView(c);
            tvSub.setText(subtitle);
            tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            tvSub.setTextColor(COLOR_TEXT_MUTED);
            tvSub.setPadding(0, dp(c, 2), 0, 0);
            textCol.addView(tvSub);
        }

        titleRow.addView(textCol);
        bar.addView(titleRow);

        return bar;
    }

    public static LinearLayout createCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 18);
        l.setPadding(pad, pad, pad, pad);
        l.setBackground(shape(COLOR_SURFACE, COLOR_BORDER, 16, c));
        return l;
    }

    public static LinearLayout createImportantCard(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 18);
        l.setPadding(pad, pad, pad, pad);
        l.setBackground(shape(COLOR_IMPORTANT_BG, COLOR_IMPORTANT_BORDER, 16, c));
        return l;
    }

    public static Button primaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setAllCaps(false);
        b.setBackground(buttonRipple(gradient(COLOR_ORANGE, COLOR_ORANGE_LIGHT, 14, c), 0x55FFFFFF));
        int padH = dp(c, 20);
        int padV = dp(c, 14);
        b.setPadding(padH, padV, padH, padV);
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(COLOR_TEXT_PRIMARY);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setAllCaps(false);
        b.setBackground(buttonRipple(shape(COLOR_SURFACE_ELEVATED, COLOR_BORDER, 12, c), 0x33F47721));
        int padH = dp(c, 16);
        int padV = dp(c, 12);
        b.setPadding(padH, padV, padH, padV);
        return b;
    }

    public static Button dangerButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setAllCaps(false);
        b.setBackground(buttonRipple(gradient(0xFFDC2626, 0xFFEF4444, 14, c), 0x55FFFFFF));
        int padH = dp(c, 20);
        int padV = dp(c, 14);
        b.setPadding(padH, padV, padH, padV);
        return b;
    }

    public static LinearLayout navCardButton(Context c, String icon, String title, String subtitle, View.OnClickListener onClick) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int padH = dp(c, 16);
        int padV = dp(c, 14);
        row.setPadding(padH, padV, padH, padV);
        row.setBackground(buttonRipple(shape(COLOR_SURFACE, COLOR_BORDER, 14, c), 0x33F47721));

        TextView tvIcon = new TextView(c);
        tvIcon.setText(icon);
        tvIcon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        tvIcon.setPadding(0, 0, dp(c, 14), 0);
        row.addView(tvIcon);

        LinearLayout textCol = new LinearLayout(c);
        textCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        textCol.setLayoutParams(lp);

        TextView tvTitle = new TextView(c);
        tvTitle.setText(title);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tvTitle.setTextColor(COLOR_TEXT_PRIMARY);
        tvTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        textCol.addView(tvTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvSub = new TextView(c);
            tvSub.setText(subtitle);
            tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvSub.setTextColor(COLOR_TEXT_MUTED);
            tvSub.setPadding(0, dp(c, 2), 0, 0);
            textCol.addView(tvSub);
        }
        row.addView(textCol);

        TextView chevron = new TextView(c);
        chevron.setText("›");
        chevron.setTextColor(COLOR_ORANGE);
        chevron.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        chevron.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        chevron.setPadding(dp(c, 6), 0, 0, 0);
        row.addView(chevron);

        row.setOnClickListener(onClick);
        return row;
    }

    public static TextView badge(Context c, String text, int textColor, int bgColor) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(textColor);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        int padH = dp(c, 8);
        int padV = dp(c, 3);
        tv.setPadding(padH, padV, padH, padV);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bgColor);
        gd.setCornerRadius(dp(c, 6));
        tv.setBackground(gd);
        return tv;
    }

    public static EditText inputField(Context c, String hint) {
        EditText et = new EditText(c);
        et.setHint(hint);
        et.setHintTextColor(COLOR_TEXT_SUBTLE);
        et.setTextColor(COLOR_TEXT_PRIMARY);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        et.setBackground(shape(0xFF0F1116, 0xFF262C36, 12, c));
        int pad = dp(c, 14);
        et.setPadding(pad, pad, pad, pad);
        return et;
    }

    public static void copyToClipboard(Context c, String label, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText(label, text));
            Toast.makeText(c, "Текст скопирован в буфер", Toast.LENGTH_SHORT).show();
        }
    }
}
