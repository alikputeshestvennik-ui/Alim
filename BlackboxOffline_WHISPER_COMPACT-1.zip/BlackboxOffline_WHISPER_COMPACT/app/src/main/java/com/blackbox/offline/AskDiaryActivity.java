
package com.blackbox.offline;
import android.app.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Local retrieval screen. It never sends diary text over the network. */
public class AskDiaryActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xff0b0c0d);

        TextView title = new TextView(this);
        title.setText("Спросить дневник");
        title.setTextSize(28);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        final EditText question = new EditText(this);
        question.setHint("Например: Что было 14 мая?");
        question.setTextColor(Color.WHITE);
        question.setHintTextColor(0xffaaaaaa);
        root.addView(question);

        Button ask = new Button(this);
        ask.setText("Найти записи");
        root.addView(ask);

        final TextView result = new TextView(this);
        result.setTextColor(Color.WHITE);
        result.setPadding(0, 12, 0, 12);
        root.addView(result);

        ask.setOnClickListener(v -> {
            String q = question.getText().toString().toLowerCase();
            StringBuilder out = new StringBuilder();
            for (Entry e : new EntryStore(this).all()) {
                String text = (e.created + " " + e.transcript).toLowerCase();
                boolean hit = e.important || (q.length() > 0 && (text.contains(q) || e.created.startsWith(q)));
                if (hit && !e.transcript.isEmpty()) {
                    out.append(e.important ? "★ " : "• ").append(e.created).append(": ").append(e.transcript).append("

");
                }
            }
            result.setText(out.length() == 0 ? "Подходящих записей не найдено." : out.toString());
        });

        setContentView(new ScrollView(this) {{ addView(root); }});
    }

    private int dp(int x){ return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
